# 判定結果の集計

## 問題

あるプログラミングコンテストの問題には `N` 個のテストケースがあります。

各テストケースの結果は `"AC"`、`"WA"`、`"TLE"`、`"RE"` のいずれかで表されます。

それぞれの結果が何個ずつあるかを求めてください。

## 入力

`input` には、整数 `N` と配列 `S` を持つオブジェクトが入っています。

`S` は長さ `N` の配列で、各要素は `"AC"`、`"WA"`、`"TLE"`、`"RE"` のいずれかです。

制約:

- `1 <= N <= 100000`

## 出力

`output` に、`"AC"`、`"WA"`、`"TLE"`、`"RE"` の個数をこのキーで持つオブジェクトを代入してください。

## 例 1

`input`:

```json
{
  "N": 6,
  "S": ["AC", "TLE", "AC", "AC", "WA", "TLE"]
}
```

期待される `output`:

```json
{
  "AC": 3,
  "WA": 1,
  "TLE": 2,
  "RE": 0
}
```

## 例 2

`input`:

```json
{
  "N": 10,
  "S": ["AC", "AC", "AC", "AC", "AC", "AC", "AC", "AC", "AC", "AC"]
}
```

期待される `output`:

```json
{
  "AC": 10,
  "WA": 0,
  "TLE": 0,
  "RE": 0
}
```

## 出典

この問題は AtCoder Beginner Contest 173 B「Judge Status Summary」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc173/tasks/abc173_b?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
