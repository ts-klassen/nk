# Programming Education

## 問題

高橋君は、年齢に応じて次のどちらかを行うプログラムを作ることにしました。

- `N` が `1` のとき、`Hello World` という文字列を返す
- `N` が `2` のとき、整数 `A` と `B` の和を返す

与えられた `input` をもとに、正しい値を `output` に代入してください。

## 入力

`input` には、整数 `N` を持つオブジェクトが入っています。

`N` は `1` または `2` です。`N` が `2` のとき、`input` にはさらに整数 `A` と `B` が入っています。

条件は次の通りです。

- `A` は `1` 以上 `9` 以下の整数
- `B` は `1` 以上 `9` 以下の整数

## 出力

`N` が `1` のときは、`output` に `"Hello World"` を代入してください。

`N` が `2` のときは、`output` に `A + B` の値を代入してください。

## 例 1

`input`:

```json
{ "N": 1 }
```

期待される `output`:

```json
"Hello World"
```

## 例 2

`input`:

```json
{ "N": 2, "A": 3, "B": 5 }
```

期待される `output`:

```json
8
```

## 出典

この問題は AtCoder Beginner Contest 112 A「Programming Education」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc112/tasks/abc112_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
