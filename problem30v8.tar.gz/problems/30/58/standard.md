# 交互に復元するパスワード

## 問題

すぬけ君は、パスワードを忘れないように紙へメモしました。
ただし、そのまま書くと危ないので、パスワードの 1 番目、3 番目、5 番目、... の文字を取り出した文字列と、2 番目、4 番目、6 番目、... の文字を取り出した文字列に分けてメモしました。

奇数番目の文字からなる文字列 `O` と、偶数番目の文字からなる文字列 `E` が与えられます。
2 つの文字列を交互に並べて、元のパスワードを復元してください。

## 入力

`input` には、文字列 `O` と `E` を持つオブジェクトが入っています。

`O` と `E` は次の条件を満たします。

- `O` と `E` は小文字の英字からなる文字列です。
- `O` と `E` の長さはそれぞれ 1 以上 50 以下です。
- `O` の長さは、`E` の長さと同じか、ちょうど 1 だけ長いです。

## 出力

`output` に、復元したパスワードを文字列として代入してください。

## 例 1

`input`:

```json
{ "O": "xyz", "E": "abc" }
```

期待される `output`:

```json
"xaybzc"
```

## 例 2

`input`:

```json
{ "O": "atcoderbeginnercontest", "E": "atcoderregularcontest" }
```

期待される `output`:

```json
"aattccooddeerrbreeggiunlnaerrccoonntteesstt"
```

## 出典

この問題は AtCoder Beginner Contest 058 B「∵∴∵」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc058/tasks/abc058_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
