# 世界のFizzBuzz

## 問題

整数 `N` が与えられます。

`N` に数字の `3` が含まれる、または `N` が `3` で割り切れる場合は `"YES"`、それ以外の場合は `"NO"` と判定してください。

## 入力

`input` には、整数 `N` が入っています。

`N` は `1` 以上 `9` 以下です。

## 出力

`output` に、条件を満たす場合は `"YES"`、そうでない場合は `"NO"` の文字列を代入してください。

## 例

`input`:

```json
2
```

期待される `output`:

```json
"NO"
```

`2` は `3` で割り切れず、数字の `3` も含みません。

`input`:

```json
9
```

期待される `output`:

```json
"YES"
```

`9` は `3` で割り切れます。

`input`:

```json
3
```

期待される `output`:

```json
"YES"
```

`3` は `3` で割り切れます。

## 出典

この問題は AtCoder Beginner Contest 006 A「世界のFizzBuzz」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc006/tasks/abc006_1?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
