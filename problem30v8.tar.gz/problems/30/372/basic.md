# ドットを削除

## 問題

英小文字と `.` からなる文字列 `S` があります。

`S` に含まれる `.` をすべて取り除いた文字列を求めてください。

## 入力

`input` には、英小文字と `.` からなる文字列 `S` が入っています。

`S` の長さは 1 以上 100 以下です。

## 出力

`output` に、`S` から `.` をすべて取り除いた文字列を代入してください。

## 例 1

`input`:

```json
".v."
```

期待される `output`:

```json
"v"
```

## 例 2

`input`:

```json
"chokudai"
```

期待される `output`:

```json
"chokudai"
```

## 例 3

`input`:

```json
"..."
```

期待される `output`:

```json
""
```

## 出典

この問題はユニークビジョンプログラミングコンテスト2024 秋（AtCoder Beginner Contest 372）A「delete .」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc372/tasks/abc372_a
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
