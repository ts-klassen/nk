# Hello,World! 判定

## 問題

文字列 `S` が与えられます。

`S` が `"Hello,World!"` と完全に同じ文字列なら `"AC"`、そうでなければ `"WA"` を答えてください。

ここで完全に同じとは、文字数が同じで、すべての位置の文字が英大文字・英小文字の違いも含めて一致していることです。

## 入力

`input` には文字列 `S` が入っています。

`S` は次の条件を満たします。

- `1 <= S.length <= 15`
- `S` は英大文字、英小文字、`,`、`!` のみからなります。

## 出力

`output` に、`S` が `"Hello,World!"` と完全に同じなら `"AC"`、そうでなければ `"WA"` の文字列を代入してください。

## 例

### 例 1

`input`:

```json
"Hello,World!"
```

期待される `output`:

```json
"AC"
```

### 例 2

`input`:

```json
"Hello,world!"
```

期待される `output`:

```json
"WA"
```

### 例 3

`input`:

```json
"Hello!World!"
```

期待される `output`:

```json
"WA"
```

## 出典

この問題は AtCoder Beginner Contest 215 A「Your First Judge」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc215/tasks/abc215_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
