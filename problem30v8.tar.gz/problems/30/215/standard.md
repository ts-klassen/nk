# 2 の何乗まで入るか

## 問題

正整数 `N` が与えられます。

`2^k <= N` を満たす最大の整数 `k` を求めてください。

## 入力

`input` には、正整数 `N` を 10 進表記で表した文字列が入っています。

`N` は `1 <= N <= 10^18` を満たします。

## 出力

`output` に、`2^k <= N` を満たす最大の整数 `k` を数値で代入してください。

## 例 1

`input`:

```json
"6"
```

期待される `output`:

```json
2
```

`k = 2` のとき `2^2 = 4 <= 6` を満たします。
一方、`k >= 3` では `2^k > 6` になります。

## 例 2

`input`:

```json
"1"
```

期待される `output`:

```json
0
```

`2^0 = 1` であることに注意してください。

## 例 3

`input`:

```json
"1000000000000000000"
```

期待される `output`:

```json
59
```

`N` は大きな値になることがあります。

## 出典

この問題は AtCoder Beginner Contest 215 B「log2(N)」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc215/tasks/abc215_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
