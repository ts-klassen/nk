# K番目の並べ替え文字列

## 問題

文字列 `S` に含まれる文字をすべて使って作れる文字列を考えます。
同じ文字が複数含まれている場合、同じ並びの文字列は 1 種類として数えます。

これらの文字列を辞書順に並べたとき、前から `K` 番目にくる文字列を求めてください。

## 入力

`input` には、文字列 `S` と整数 `K` を持つオブジェクトが入っています。

- `1 <= S.length <= 8`
- `S` は英小文字のみからなる文字列です。
- `S` の文字を並べ替えて作れる異なる文字列は `K` 種類以上あります。

## 出力

`output` に、辞書順で前から `K` 番目にくる文字列を代入してください。

## 例 1

`input`:

```json
{ "S": "aab", "K": 2 }
```

期待される `output`:

```json
"aba"
```

`aab` から作れる異なる文字列は、辞書順に `aab`, `aba`, `baa` です。

## 例 2

`input`:

```json
{ "S": "baba", "K": 4 }
```

期待される `output`:

```json
"baab"
```

## 例 3

`input`:

```json
{ "S": "ydxwacbz", "K": 40320 }
```

期待される `output`:

```json
"zyxwdcba"
```

## 出典

この問題は AtCoder Beginner Contest 215 C「One More aab aba baa」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc215/tasks/abc215_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
