# 3 桁の数の回転和

## 問題

3 つの数字 `x`, `y`, `z` をこの順に並べてできる 3 桁の整数を `xyz` と表します。

どの桁も `0` でない 3 桁の整数 `abc` が与えられます。

`abc + bca + cab` を求めてください。

## 入力

`input` には、どの桁も `0` でない 3 桁の整数が入っています。

## 制約

- `input` は、どの桁も `0` でない 3 桁の整数です。

## 出力

`output` に、`abc + bca + cab` の値を数値として代入してください。

## 例 1

`input`:

```json
123
```

期待される `output`:

```json
666
```

`123 + 231 + 312 = 666` です。

## 例 2

`input`:

```json
999
```

期待される `output`:

```json
2997
```

`999 + 999 + 999 = 2997` です。

## 出典

この問題は HHKB プログラミングコンテスト 2022（AtCoder Beginner Contest 235）A「Rotate」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc235/tasks/abc235_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
