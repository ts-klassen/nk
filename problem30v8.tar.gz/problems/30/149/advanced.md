# X 以上の最小の素数

## 問題

整数 `X` が与えられます。

`X` 以上の整数のうち、最も小さい素数を求めてください。

素数とは、2 以上の整数で、1 と自分自身以外の正の約数を持たない整数のことです。

## 入力

`input` には整数 `X` が入っています。

`X` は 2 以上 100000 以下です。

## 出力

`output` に、`X` 以上の素数のうち最小のものを数値で代入してください。

## 例 1

`input`:

```json
20
```

期待される `output`:

```json
23
```

## 例 2

`input`:

```json
2
```

期待される `output`:

```json
2
```

`X` 自身が素数である場合もあります。

## 例 3

`input`:

```json
99992
```

期待される `output`:

```json
100003
```

## 出典

この問題は AtCoder Beginner Contest 149 C「Next Prime」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc149/tasks/abc149_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
