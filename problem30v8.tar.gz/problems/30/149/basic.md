# 文字列の連結

## 問題

英小文字だけからなる 2 つの文字列 `S` と `T` があります。

`T` の後ろに `S` を空白なしでつなげた文字列を作ってください。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

- `S` と `T` は英小文字だけからなる文字列です。
- `S` と `T` の長さは、それぞれ 1 以上 100 以下です。

## 出力

`output` に、`T` と `S` をこの順に空白なしでつなげた文字列を代入してください。

## 例 1

`input`:

```json
{
  "S": "oder",
  "T": "atc"
}
```

期待される `output`:

```json
"atcoder"
```

## 例 2

`input`:

```json
{
  "S": "humu",
  "T": "humu"
}
```

期待される `output`:

```json
"humuhumu"
```

## 出典

この問題は AtCoder Beginner Contest 149 A「Strings」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc149/tasks/abc149_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
