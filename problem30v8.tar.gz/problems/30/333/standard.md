# 五角形の線分

## 問題

正五角形 `P` の 5 つの頂点を、周上に `A`, `B`, `C`, `D`, `E` の順に名付けます。

点 `S1` と点 `S2` を結ぶ線分と、点 `T1` と点 `T2` を結ぶ線分の長さが等しいか判定してください。

## 入力

`input` には、次の 4 つの文字列を持つオブジェクトが入っています。

- `S1`
- `S2`
- `T1`
- `T2`

それぞれの文字列は `A`, `B`, `C`, `D`, `E` のいずれかです。

`S1` と `S2` は異なる文字列で、`T1` と `T2` も異なる文字列です。

## 出力

2 つの線分の長さが等しい場合は、`output` に `"Yes"` を代入してください。

等しくない場合は、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{
  "S1": "A",
  "S2": "C",
  "T1": "E",
  "T2": "C"
}
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
{
  "S1": "D",
  "S2": "A",
  "T1": "E",
  "T2": "A"
}
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
{
  "S1": "B",
  "S2": "D",
  "T1": "B",
  "T2": "D"
}
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は トヨタ自動車プログラミングコンテスト2023#8（AtCoder Beginner Contest 333） B「Pentagon」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc333/tasks/abc333_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
