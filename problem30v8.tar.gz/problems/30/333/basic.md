# N を N 個つなげる

## 問題

`1` 以上 `9` 以下の整数 `N` が与えられます。

数字 `N` を `N` 個つなげてできる文字列を作ってください。

## 入力

`input` には整数 `N` が入っています。

## 出力

`output` に、数字 `N` を `N` 個つなげてできる文字列を代入してください。

## 例 1

`input`:

```json
3
```

期待される `output`:

```json
"333"
```

## 例 2

`input`:

```json
9
```

期待される `output`:

```json
"999999999"
```

## 出典

この問題は トヨタ自動車プログラミングコンテスト2023#8（AtCoder Beginner Contest 333）A「Three Threes」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc333/tasks/abc333_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
