# 母音の判定

## 問題

英小文字 `c` が 1 文字与えられます。
`c` が母音であるかを判定してください。

英小文字のうち、母音は `a`、`e`、`i`、`o`、`u` の 5 つです。

## 入力

`input` には英小文字 1 文字の文字列が入っています。

## 出力

`input` が母音であるときは、`output` に `"vowel"` を代入してください。
そうでないときは、`output` に `"consonant"` を代入してください。

## 例

`input`:

```json
"a"
```

期待される `output`:

```json
"vowel"
```

`input`:

```json
"z"
```

期待される `output`:

```json
"consonant"
```

`input`:

```json
"s"
```

期待される `output`:

```json
"consonant"
```

## 出典

この問題は AtCoder Beginner Contest 049 A「居合を終え、青い絵を覆う」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc049/tasks/abc049_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
