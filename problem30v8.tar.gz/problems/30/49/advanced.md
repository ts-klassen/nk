# 白昼夢

## 問題

英小文字からなる文字列 `S` が与えられます。

文字列 `T` は最初、空文字列です。次の 4 つの文字列のうち 1 つを `T` の末尾に追加する操作を、好きな回数だけ行えます。

- `dream`
- `dreamer`
- `erase`
- `eraser`

この操作によって `T` を `S` と同じ文字列にできるか判定してください。

## 入力

`input` には英小文字からなる文字列 `S` が入っています。

制約:

- `1 <= S.length <= 100000`
- `S` は英小文字からなる文字列です。

## 出力

`T` を `S` と同じ文字列にできる場合は、`output` に `"YES"` を代入してください。できない場合は、`output` に `"NO"` を代入してください。

## 例

`input`:

```json
"erasedream"
```

期待される `output`:

```json
"YES"
```

`erase`、`dream` の順に追加すると、`S` と同じ文字列にできます。

## 出典

この問題は AtCoder Beginner Contest 049 C「白昼夢」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc049/tasks/arc065_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
