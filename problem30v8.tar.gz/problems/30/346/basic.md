# 隣り合う積

## 問題

整数列 `A` があります。
`A` の隣り合う 2 つの要素を順に掛け合わせた値を求めます。

具体的には、`B_i = A_i * A_{i+1}` として、`B_1, B_2, ..., B_{N-1}` を求めてください。

## 入力

`input` には、整数 `N` と、長さ `N` の整数配列 `A` を持つオブジェクトが入っています。

- `2 <= N <= 100`
- `1 <= A_i <= 100`

## 出力

`output` には、`A` の隣り合う要素どうしの積を先頭から順に並べた配列を代入してください。

## 例 1

`input`:

```json
{
  "N": 3,
  "A": [3, 4, 6]
}
```

期待される `output`:

```json
[12, 24]
```

## 例 2

`input`:

```json
{
  "N": 5,
  "A": [22, 75, 26, 45, 72]
}
```

期待される `output`:

```json
[1650, 1950, 1170, 3240]
```

## 出典

この問題は ユニークビジョンプログラミングコンテスト2024 春（AtCoder Beginner Contest 346） A「Adjacent Product」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc346/tasks/abc346_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
