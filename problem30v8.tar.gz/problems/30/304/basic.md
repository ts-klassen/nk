# First Player

## 問題

`N` 人が円卓に座っています。
`input.people` の先頭から順に時計回りに座っていて、最後の人の次には先頭の人が座っています。

それぞれの人には名前 `S` と年齢 `A` があります。
同じ名前の人はおらず、同じ年齢の人もいません。

年齢が最も小さい人を起点として、時計回りの順番に `N` 人全員の名前を並べてください。

## 入力

`input` には、整数 `N` と配列 `people` を持つオブジェクトが入っています。

- `N` は人数です。
- `people` の長さは `N` です。
- `people[i]` は、時計回りで `i + 1` 番目に座っている人を表すオブジェクトです。
- `people[i].S` はその人の名前、`people[i].A` はその人の年齢です。

制約:

- `2 <= N <= 100`
- `S` は英小文字のみからなる長さ `1` 以上 `10` 以下の文字列
- 名前はすべて異なる
- `0 <= A <= 1000000000`
- 年齢はすべて異なる

## 出力

`output` に、年齢が最も小さい人を先頭にして、時計回りの順に名前を並べた配列を代入してください。

## 例 1

`input`:

```json
{
  "N": 5,
  "people": [
    { "S": "alice", "A": 31 },
    { "S": "bob", "A": 41 },
    { "S": "carol", "A": 5 },
    { "S": "dave", "A": 92 },
    { "S": "ellen", "A": 65 }
  ]
}
```

期待される `output`:

```json
["carol", "dave", "ellen", "alice", "bob"]
```

## 例 2

`input`:

```json
{
  "N": 2,
  "people": [
    { "S": "takahashi", "A": 1000000000 },
    { "S": "aoki", "A": 999999999 }
  ]
}
```

期待される `output`:

```json
["aoki", "takahashi"]
```

## 出典

この問題は 東京海上日動プログラミングコンテスト2023（AtCoder Beginner Contest 304） A「First Player」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc304/tasks/abc304_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
