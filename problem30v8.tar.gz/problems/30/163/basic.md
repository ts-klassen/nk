# 円の周長

## 問題

半径 `R` の円があります。

円の周長を求めてください。

## 入力

`input` には、円の半径を表す整数 `R` が入っています。

`R` は `1 <= R <= 100` を満たします。

## 出力

`output` に、半径 `R` の円の周長を表す数値を代入してください。

想定値との絶対誤差または相対誤差が `10^-2` 以下であれば正解です。

## 例 1

`input`:

```json
1
```

期待される `output`:

```json
6.28318530717958623200
```

この例では、`6.28` も許容範囲内の値です。

## 例 2

`input`:

```json
73
```

期待される `output`:

```json
458.67252742410977361942
```

## 出典

この問題は AtCoder Beginner Contest 163 A「Circle Pond」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc163/tasks/abc163_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
