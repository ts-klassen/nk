# ABC に並べ替える

## 問題

長さ 3 の英大文字からなる文字列 `S` が与えられます。

`S` の文字を並べ替えて、文字列 `"ABC"` と一致させられるか判定してください。

## 入力

`input` には、英大文字からなる長さ 3 の文字列 `S` が入っています。

## 出力

`S` の文字を並べ替えて `"ABC"` と一致させられるなら、`output` に `"Yes"` を代入してください。
そうでないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
"BAC"
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
"AAC"
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
"ABC"
```

期待される `output`:

```json
"Yes"
```

## 例 4

`input`:

```json
"ARC"
```

期待される `output`:

```json
"No"
```

## 出典

この問題はトヨタシステムズプログラミングコンテスト2024（AtCoder Beginner Contest 377) A「Rearranging ABC」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc377/tasks/abc377_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
