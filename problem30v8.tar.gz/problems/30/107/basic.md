# 列車の後ろからの番号

## 問題

`N` 両編成の列車があります。
この列車の前から `i` 両目の車両は、後ろから何両目でしょうか。

`N` と `i` は、次の条件を満たします。

- `1 <= N <= 100`
- `1 <= i <= N`

## 入力

`input` には、整数 `N` と `i` を持つオブジェクトが入っています。

## 出力

`output` に、前から `i` 両目の車両が後ろから何両目かを表す整数を代入してください。

## 例 1

`input`:

```json
{ "N": 4, "i": 2 }
```

期待される `output`:

```json
3
```

4 両編成の列車で、前から 2 両目の車両は後ろから 3 両目です。

## 例 2

`input`:

```json
{ "N": 1, "i": 1 }
```

期待される `output`:

```json
1
```

## 例 3

`input`:

```json
{ "N": 15, "i": 11 }
```

期待される `output`:

```json
5
```

## 出典

この問題は AtCoder Beginner Contest 107 A「Train」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc107/tasks/abc107_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
