# 部分列の反転

## 問題

正整数 `N`, `L`, `R` が与えられます。

数列 `A = [1, 2, ..., N]` を作り、`L` 番目から `R` 番目までの部分だけを逆順に並べ替えます。

操作後の数列を求めてください。

## 入力

`input` には、正整数 `N`, `L`, `R` を持つオブジェクトが入っています。

`N`, `L`, `R` は次の条件を満たします。

- `1 <= L <= R <= N <= 100`

## 出力

`output` に、操作後の数列を整数の配列として代入してください。

## 例

`input`:

```json
{ "N": 5, "L": 2, "R": 3 }
```

期待される `output`:

```json
[1, 3, 2, 4, 5]
```

`input`:

```json
{ "N": 7, "L": 1, "R": 1 }
```

期待される `output`:

```json
[1, 2, 3, 4, 5, 6, 7]
```

`input`:

```json
{ "N": 10, "L": 1, "R": 10 }
```

期待される `output`:

```json
[10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
```

## 出典

この問題は AtCoder Beginner Contest 356 A「Subsegment Reverse」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc356/tasks/abc356_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
