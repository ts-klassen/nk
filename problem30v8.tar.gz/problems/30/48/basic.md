# AtCoder \*\*\* Contest

## 問題

すぬけ君は、`AtCoder s Contest` という名前のコンテストを開こうとしています。

`s` は長さ 1 以上 100 以下の文字列です。1 文字目は英大文字、2 文字目以降は英小文字です。

すぬけ君は、このコンテストの略称を `AxC` に決めました。ここで、`x` は `s` の先頭の英大文字です。

文字列 `s` が与えられるので、コンテストの略称を求めてください。

## 入力

`input` には文字列 `s` が入っています。

## 出力

`output` に、`"A"`、`s` の先頭文字、`"C"` をこの順につなげた文字列を代入してください。

## 例 1

`input`:

```json
"Beginner"
```

期待される `output`:

```json
"ABC"
```

## 例 2

`input`:

```json
"Snuke"
```

期待される `output`:

```json
"ASC"
```

## 例 3

`input`:

```json
"X"
```

期待される `output`:

```json
"AXC"
```

## 出典

この問題は AtCoder Beginner Contest 048 A「AtCoder \*\*\* Contest」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc048/tasks/abc048_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
