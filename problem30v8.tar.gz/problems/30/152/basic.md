# AC or WA

## 問題

高橋君は、あるプログラミングコンテストの問題 A にコードを提出しました。

この問題には `N` 個のテストケースがあり、すべてのテストケースに正解した場合だけ AC になります。高橋君の提出は、そのうち `M` 個のテストケースに正解しました。

高橋君の提出が AC になるか判定してください。

## 入力

`input` には、整数 `N` と `M` を持つオブジェクトが入っています。

- `N`: テストケースの個数
- `M`: 正解したテストケースの個数

制約:

- `1 <= N <= 100`
- `0 <= M <= N`
- `N` と `M` は整数

## 出力

高橋君の提出が AC になる場合は `output` に `"Yes"` を、そうでない場合は `"No"` を代入してください。

## 例

### 例 1

`input`:

```json
{ "N": 3, "M": 3 }
```

期待される `output`:

```json
"Yes"
```

### 例 2

`input`:

```json
{ "N": 3, "M": 2 }
```

期待される `output`:

```json
"No"
```

### 例 3

`input`:

```json
{ "N": 1, "M": 1 }
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 152 A「AC or WA」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc152/tasks/abc152_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
