# 複数形

## 問題

英小文字からなる文字列 `W` が与えられます。

`W` の末尾に英小文字の `"s"` を付け足した文字列を作ってください。

## 入力

`input` には、英小文字からなる文字列 `W` が入っています。

- `W` の長さは 1 以上 10 以下です。

## 出力

`output` に、`W` の末尾に `"s"` を付け足した文字列を代入してください。

## 例

`input`:

```json
"dog"
```

期待される `output`:

```json
"dogs"
```

`input`:

```json
"chokudai"
```

期待される `output`:

```json
"chokudais"
```

## 出典

この問題は AtCoder Beginner Contest 029 A「複数形」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc029/tasks/abc029_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
