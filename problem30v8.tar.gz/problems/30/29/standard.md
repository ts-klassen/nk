# 文字 r を含む文字列の数

## 問題

英小文字だけからなる 12 個の文字列があります。
このうち、文字 `r` を含む文字列がいくつあるかを求めてください。

1 つの文字列に `r` が複数回出てくる場合でも、その文字列は 1 個として数えます。

## 入力

`input` には、英小文字だけからなる 12 個の文字列を並べた配列が入っています。

各文字列の長さは 1 以上 10 以下で、12 個の文字列はすべて異なります。

## 出力

`output` に、文字 `r` を含む文字列の個数を整数で代入してください。

## 例 1

`input`:

```json
[
  "january",
  "february",
  "march",
  "april",
  "may",
  "june",
  "july",
  "august",
  "september",
  "october",
  "november",
  "december"
]
```

期待される `output`:

```json
8
```

## 例 2

`input`:

```json
[
  "rrrrrrrrrr",
  "srrrrrrrrr",
  "rsr",
  "ssr",
  "rrs",
  "srsrrrrrr",
  "rssrrrrrr",
  "sss",
  "rrr",
  "srr",
  "rsrrrrrrrr",
  "ssrrrrrrrr"
]
```

期待される `output`:

```json
11
```

## 出典

この問題は AtCoder Beginner Contest 029 B「カキ」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc029/tasks/abc029_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
