# パスワード候補の列挙

## 問題

あるパスワードについて、次のことが分かっています。

- 長さは `N` 文字である。
- 使われる文字は、小文字の `a`、`b`、`c` だけである。

この条件を満たす文字列をすべて列挙してください。

## 入力

`input` には、パスワードの長さを表す整数 `N` が入っています。

`N` は `1` 以上 `8` 以下です。

## 出力

`output` に、条件を満たすすべての文字列を辞書順で並べた配列を代入してください。

ここでの辞書順では、先頭から順に文字を比べ、はじめて違う文字が出た位置で `a`、`b`、`c` の順に早いものを先にします。

## 例1

`input`:

```json
1
```

期待される `output`:

```json
["a", "b", "c"]
```

## 例2

`input`:

```json
2
```

期待される `output`:

```json
[
  "aa",
  "ab",
  "ac",
  "ba",
  "bb",
  "bc",
  "ca",
  "cb",
  "cc"
]
```

## 出典

この問題は AtCoder Beginner Contest 029 C「Brute-force Attack」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc029/tasks/abc029_c?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
