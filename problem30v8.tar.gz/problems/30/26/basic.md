# 掛け算の最大値

## 問題

正の偶数 `A` が与えられます。

正の整数 `x` と `y` を選び、`x + y = A` となるようにします。
このとき、`x * y` として作れる最大値を求めてください。

## 入力

`input` には、整数 `A` が入っています。

`A` は正の偶数で、`2 <= A <= 100` を満たします。

## 出力

`output` に、`x + y = A` となる正の整数 `x` と `y` について、`x * y` の最大値を数値で代入してください。

## 例

`input`:

```json
10
```

期待される `output`:

```json
25
```

`input`:

```json
60
```

期待される `output`:

```json
900
```

## 出典

この問題は AtCoder Beginner Contest 026 A「掛け算の最大値」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc026/tasks/abc026_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
