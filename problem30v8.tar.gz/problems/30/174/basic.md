# 冷房を入れるか

## 問題

あなたは、室温が 30 度以上のとき、かつそのときに限り、冷房の電源を入れます。

今の室温は `X` 度です。冷房の電源を入れるか判定してください。

## 入力

`input` には、現在の室温 `X` を表す整数が入っています。

`X` は `-40` 以上 `40` 以下です。

## 出力

冷房の電源を入れるなら `output` に `"Yes"` を、入れないなら `"No"` を代入してください。

## 例 1

`input`:

```json
25
```

期待される `output`:

```json
"No"
```

## 例 2

`input`:

```json
30
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 174 A「Air Conditioner」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc174/tasks/abc174_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
