# abc の並び替え

## 問題

`a`、`b`、`c` からなる長さ 3 の文字列 `S` があります。

`S` が `"abc"` の 3 文字を並び替えて作れる文字列かどうかを判定してください。

## 入力

`input` には、文字列 `S` が入っています。

`S` は次の条件を満たします。

- 長さは 3
- 使われる文字は `"a"`、`"b"`、`"c"` のいずれか

## 出力

`S` が `"abc"` の 3 文字を並び替えて作れるなら、`output` に `"Yes"` を代入してください。

そうでないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
"bac"
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
"bab"
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
"abc"
```

期待される `output`:

```json
"Yes"
```

## 例 4

`input`:

```json
"aaa"
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 093 A「abc of ABC」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc093/tasks/abc093_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
