# 文字列の省略

## 問題

`internationalization` という英単語は、`i18n` と略されることがあります。これは、先頭文字 `i` と末尾文字 `n` の間に 18 文字が挟まっていることに由来します。

`input` に入っている文字列 `s` について、同じ規則で省略形を作ってください。

## 制約

- `s` の長さは 3 以上 100 以下です。
- `s` は英小文字のみからなります。

## 入力

`input` には、文字列 `s` が入っています。

## 出力

`output` に、`s` の先頭文字、先頭と末尾の間にある文字数、`s` の末尾文字をこの順につなげた文字列を代入してください。

## 例 1

`input`:

```json
"internationalization"
```

期待される `output`:

```json
"i18n"
```

## 例 2

`input`:

```json
"smiles"
```

期待される `output`:

```json
"s4s"
```

## 例 3

`input`:

```json
"xyz"
```

期待される `output`:

```json
"x1z"
```

## 出典

この問題は AtCoder Beginner Contest 069 B「i18n」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc069/tasks/abc069_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
