# K-City

## 問題

K 市には、東西方向に `n` 本、南北方向に `m` 本の通りがあります。
東西方向の通りと南北方向の通りは、すべて互いに交わっています。

4 本の通りに囲まれた最小の領域を「街区」と呼びます。
K 市にある街区の個数を求めてください。

## 入力

`input` には、整数 `n` と `m` を持つオブジェクトが入っています。

- `2 <= n, m <= 100`

## 出力

`output` に、K 市にある街区の個数を表す整数を代入してください。

## 例

`input`:

```json
{ "n": 3, "m": 4 }
```

期待される `output`:

```json
6
```

`input`:

```json
{ "n": 2, "m": 2 }
```

期待される `output`:

```json
1
```

## 出典

この問題は AtCoder Beginner Contest 069 A「K-City」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc069/tasks/abc069_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
