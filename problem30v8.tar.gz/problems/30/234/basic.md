# Weird Function

## 問題

関数 `f` を `f(x) = x^2 + 2x + 3` と定義します。

整数 `t` が与えられるので、`f(f(f(t) + t) + f(f(t)))` の値を求めてください。
答えは `2 * 10^9` 以下の整数であることが保証されます。

## 入力

`input` には、`0 <= t <= 10` を満たす整数 `t` が入っています。

## 出力

`output` に、`f(f(f(t) + t) + f(f(t)))` の値を整数で代入してください。

## 例 1

`input`:

```json
0
```

期待される `output`:

```json
1371
```

## 例 2

`input`:

```json
3
```

期待される `output`:

```json
722502
```

## 例 3

`input`:

```json
10
```

期待される `output`:

```json
1111355571
```

## 出典

この問題は AtCoder Beginner Contest 234 A「Weird Function」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc234/tasks/abc234_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
