# ASCII コード

## 問題

英小文字 `a`, `b`, ..., `z` の ASCII 文字コードは、この順に `97`, `98`, ..., `122` です。

`97` 以上 `122` 以下の整数 `N` が与えられます。ASCII 文字コードが `N` である英小文字を求めてください。

## 入力

`input` には、整数 `N` が入っています。

## 制約

- `input` は `97` 以上 `122` 以下の整数です。

## 出力

`output` に、ASCII 文字コードが `N` である英小文字 1 文字の文字列を代入してください。

## 例 1

`input`:

```json
97
```

期待される `output`:

```json
"a"
```

## 例 2

`input`:

```json
122
```

期待される `output`:

```json
"z"
```

## 出典

この問題は AtCoder Beginner Contest 252 A「ASCII code」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc252/tasks/abc252_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
