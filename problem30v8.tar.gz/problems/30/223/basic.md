# 100円硬貨だけの金額

## 問題

高橋君の財布には、100 円硬貨が 1 枚以上入っています。
財布にはそれ以外のものは入っていません。

財布の中の合計金額が `X` 円である可能性があるかを判定してください。

## 入力

`input` には、整数 `X` が入っています。

- `0 <= X <= 1000`

## 出力

財布の中の合計金額が `X` 円である可能性がある場合は、`output` に `"Yes"` を代入してください。
そうでない場合は、`output` に `"No"` を代入してください。

## 例

`input`:

```json
500
```

期待される `output`:

```json
"Yes"
```

100 円硬貨が 5 枚入っているとき、合計金額は 500 円になります。

`input`:

```json
40
```

期待される `output`:

```json
"No"
```

`input`:

```json
0
```

期待される `output`:

```json
"No"
```

財布には 100 円硬貨が 1 枚以上入っていることに注意してください。

## 出典

この問題は AtCoder Beginner Contest 223 A「Exact Price」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc223/tasks/abc223_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
