# 英語らしい単語を探す

## 問題

英小文字からなる `N` 個の文字列 `W` が与えられます。

`W` の中に、`"and"`、`"not"`、`"that"`、`"the"`、`"you"` のいずれかと完全に一致する文字列が 1 つ以上あるか判定してください。

## 入力

`input` には、次のプロパティを持つオブジェクトが入っています。

- `N`: 単語数を表す整数
- `W`: 英小文字だけからなる文字列の配列

`N` は `1` 以上 `100` 以下です。`W` の長さは `N` で、各文字列の長さは `1` 以上 `50` 以下です。

## 出力

`W` の中に `"and"`、`"not"`、`"that"`、`"the"`、`"you"` のいずれかと完全に一致する文字列が 1 つ以上あれば、`output` に `"Yes"` を代入してください。

そうでない場合は、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{
  "N": 10,
  "W": ["in", "that", "case", "you", "should", "print", "yes", "and", "not", "no"]
}
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
{
  "N": 10,
  "W": ["in", "diesem", "fall", "sollten", "sie", "no", "und", "nicht", "yes", "ausgeben"]
}
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 295 A「Probably English」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc295/tasks/abc295_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
