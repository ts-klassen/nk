# ?UPC

## 問題

文字列 `S` が与えられます。

`S` の 1 文字目と文字列 `"UPC"` を、この順に結合した文字列を作ってください。

## 入力

`input` には文字列 `S` が入っています。

`S` は長さ 1 以上 100 以下の文字列です。1 文字目は英大文字で、2 文字目以降は英小文字です。

## 出力

`output` に、`S` の 1 文字目と `"UPC"` をこの順に結合した文字列を代入してください。

## 例 1

`input`:

```json
"Kyoto"
```

期待される `output`:

```json
"KUPC"
```

`"Kyoto"` の 1 文字目は `"K"` なので、答えは `"KUPC"` です。

## 例 2

`input`:

```json
"Tohoku"
```

期待される `output`:

```json
"TUPC"
```

## 出典

この問題は HHKBプログラミングコンテスト2025(AtCoder Beginner Contest 388) A「?UPC」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc388/tasks/abc388_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
