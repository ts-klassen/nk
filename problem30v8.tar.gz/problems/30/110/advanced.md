# 文字列変換

## 問題

英小文字のみからなる文字列 `S` と `T` があります。

文字列 `S` に対して、次の操作を何度でも行えます。

操作: 2 つの異なる英小文字 `c1`, `c2` を選び、`S` に含まれるすべての `c1` を `c2` に、すべての `c2` を `c1` に置き換えます。

0 回以上の操作で、`S` を `T` と一致させられるか判定してください。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

- `1 <= S.length <= 200000`
- `S.length === T.length`
- `S` と `T` は英小文字のみからなります。

## 出力

`S` を `T` と一致させられる場合は、`output` に `"Yes"` を代入してください。

一致させられない場合は、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{ "S": "azzel", "T": "apple" }
```

期待される `output`:

```json
"Yes"
```

たとえば、`e` と `l` を入れ替え、そのあと `z` と `p` を入れ替えると、`azzel` を `apple` にできます。

## 例 2

`input`:

```json
{ "S": "chokudai", "T": "redcoder" }
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
{ "S": "abcdefghijklmnopqrstuvwxyz", "T": "ibyhqfrekavclxjstdwgpzmonu" }
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 110 C「String Transformation」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc110/tasks/abc110_c?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
