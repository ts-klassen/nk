# 大文字は何文字目？

## 問題

英大文字および英小文字からなる文字列 `S` があります。

`S` には、英大文字がちょうど 1 文字だけ含まれていて、それ以外の文字はすべて英小文字です。

大文字が `S` の先頭から何文字目にあるかを求めてください。先頭の文字は 1 文字目として数えます。

## 入力

`input` には、英大文字および英小文字からなる文字列 `S` が入っています。

`S` の長さは 2 以上 100 以下で、英大文字はちょうど 1 文字だけ含まれます。

## 出力

`output` に、大文字が `S` の先頭から何文字目にあるかを表す整数を代入してください。

## 例

### 例 1

`input`:

```json
"aBc"
```

期待される `output`:

```json
2
```

### 例 2

`input`:

```json
"xxxxxxXxxx"
```

期待される `output`:

```json
7
```

### 例 3

`input`:

```json
"Zz"
```

期待される `output`:

```json
1
```

## 出典

この問題は AtCoder Beginner Contest 291（Sponsored by TOYOTA SYSTEMS） A「camel Case」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc291/tasks/abc291_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
- スポンサー表記: Sponsored by TOYOTA SYSTEMS
