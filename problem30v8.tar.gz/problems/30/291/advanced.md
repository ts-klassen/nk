# 同じ座標を訪れたか

## 問題

二次元平面の原点 `(0, 0)` に人がいます。

長さ `N` の文字列 `S` に従って、左から順に `N` 回移動します。各文字が表す移動は次の通りです。

- `R`: x 座標を 1 増やす
- `L`: x 座標を 1 減らす
- `U`: y 座標を 1 増やす
- `D`: y 座標を 1 減らす

始点と、各移動後の座標をすべて見たとき、同じ座標が 2 回以上現れるか判定してください。

## 入力

`input` には、整数 `N` と文字列 `S` を持つオブジェクトが入っています。

`S` は `R`, `L`, `U`, `D` のみからなる長さ `N` の文字列です。

制約:

- `1 <= N <= 200000`

## 出力

同じ座標が 2 回以上現れるなら、`output` に `"Yes"` を代入してください。

同じ座標が一度も重ならないなら、`output` に `"No"` を代入してください。

## 例

`input`:

```json
{
  "N": 5,
  "S": "RLURU"
}
```

期待される `output`:

```json
"Yes"
```

この例では、座標は `(0, 0)`, `(1, 0)`, `(0, 0)`, `(0, 1)`, `(1, 1)`, `(1, 2)` と変化します。始点の `(0, 0)` をもう一度訪れるため、答えは `"Yes"` です。

`input`:

```json
{
  "N": 20,
  "S": "URDDLLUUURRRDDDDLLLL"
}
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 291（Sponsored by TOYOTA SYSTEMS）C「LRUD Instructions 2」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc291/tasks/abc291_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
