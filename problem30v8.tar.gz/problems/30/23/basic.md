# 加算王

## 問題

2 桁の正整数 `X` があります。

`X` の十の位と一の位を足した値を求めてください。

## 入力

`input` には、2 桁の正整数 `X` が整数として入っています。

`X` は `10` 以上 `99` 以下です。

## 出力

`output` に、`X` の各位の和を表す整数を代入してください。

## 例

`input`:

```json
23
```

期待される `output`:

```json
5
```

`23` は、十の位が `2`、一の位が `3` なので、答えは `5` です。

## 出典

この問題は AtCoder Beginner Contest 023 A「加算王」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc023/tasks/abc023_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
