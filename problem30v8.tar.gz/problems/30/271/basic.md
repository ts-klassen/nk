# 2桁の16進表記

## 問題

16進表記では、`0` から `9` に加えて、10 から 15 に対応する数字として `A` から `F` を使います。

0 以上 255 以下の整数 `N` を、ちょうど 2 桁の16進表記に変換してください。1 桁になる場合は、先頭に `0` を付けます。

英大文字と英小文字は区別します。`A` から `F` は必ず英大文字で表してください。

## 入力

`input` には、0 以上 255 以下の整数 `N` が入っています。

## 出力

`output` に、`N` をちょうど 2 桁の16進表記にした文字列を代入してください。

## 例 1

`input`:

```json
99
```

期待される `output`:

```json
"63"
```

## 例 2

`input`:

```json
12
```

期待される `output`:

```json
"0C"
```

## 例 3

`input`:

```json
0
```

期待される `output`:

```json
"00"
```

## 例 4

`input`:

```json
255
```

期待される `output`:

```json
"FF"
```

## 出典

この問題は 京セラプログラミングコンテスト2022(AtCoder Beginner Contest 271) A「484558」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc271/tasks/abc271_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
