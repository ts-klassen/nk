# 町の合併

## 問題

`N` 個の町が合併して、1 つの新しい市になります。合併前の `i` 番目の町の名前は `S_i`、人口は `P_i` 人です。

新しい市の名前は、次のルールで決めます。

- ある町の人口が、`N` 個の町の合計人口の半分を超えているなら、新しい市の名前はその町の名前にする。
- そのような町が存在しないなら、新しい市の名前は `"atcoder"` にする。

合併後の新しい市の名前を求めてください。

## 入力

`input` には、整数 `N` と配列 `towns` を持つオブジェクトが入っています。

`towns` には `N` 個のオブジェクトが入っており、それぞれのオブジェクトは町の名前 `S` と人口 `P` を持ちます。

- `2 <= N <= 1000`
- `S` は英小文字だけからなる長さ `1` 以上 `20` 以下の文字列
- `1 <= P <= 100000`
- すべての町の名前 `S` は異なる

## 出力

`output` に、合併後の新しい市の名前を文字列で代入してください。

## 例 1

`input`:

```json
{
  "N": 4,
  "towns": [
    { "S": "unagi", "P": 20 },
    { "S": "usagi", "P": 13 },
    { "S": "snuke", "P": 42 },
    { "S": "smeke", "P": 7 }
  ]
}
```

期待される `output`:

```json
"snuke"
```

## 例 2

`input`:

```json
{
  "N": 5,
  "towns": [
    { "S": "a", "P": 10 },
    { "S": "b", "P": 20 },
    { "S": "c", "P": 30 },
    { "S": "d", "P": 40 },
    { "S": "e", "P": 100 }
  ]
}
```

期待される `output`:

```json
"atcoder"
```

## 例 3

`input`:

```json
{
  "N": 14,
  "towns": [
    { "S": "yasuzuka", "P": 3340 },
    { "S": "uragawara", "P": 4032 },
    { "S": "oshima", "P": 2249 },
    { "S": "maki", "P": 2614 },
    { "S": "kakizaki", "P": 11484 },
    { "S": "ogata", "P": 10401 },
    { "S": "kubiki", "P": 9746 },
    { "S": "yoshikawa", "P": 5142 },
    { "S": "joetsu", "P": 100000 },
    { "S": "nakago", "P": 4733 },
    { "S": "itakura", "P": 7517 },
    { "S": "kiyosato", "P": 3152 },
    { "S": "sanwa", "P": 6190 },
    { "S": "nadachi", "P": 3169 }
  ]
}
```

期待される `output`:

```json
"joetsu"
```

## 出典

この問題は AtCoder Beginner Contest 033 B「町の合併」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc033/tasks/abc033_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
