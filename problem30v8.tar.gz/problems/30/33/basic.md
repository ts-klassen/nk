# 暗証番号

## 問題

プレイヤーが入力した 4 文字の暗証番号があります。

暗証番号の各文字は `0` から `9` までの数字です。先頭が `0` になることもあります。

安全上、4 文字すべてが同じ数字である暗証番号かどうかを判定してください。

## 入力

`input` には、`0` から `9` までの数字からなる長さ 4 の文字列が入っています。

この文字列を `N` とします。

## 出力

`N` の 4 文字すべてが同じ数字なら、`output` に `"SAME"` を代入してください。

そうでなければ、`output` に `"DIFFERENT"` を代入してください。

## 例 1

`input`:

```json
"2222"
```

期待される `output`:

```json
"SAME"
```

## 例 2

`input`:

```json
"1221"
```

期待される `output`:

```json
"DIFFERENT"
```

## 例 3

`input`:

```json
"0000"
```

期待される `output`:

```json
"SAME"
```

## 出典

この問題は AtCoder Beginner Contest 033 A「暗証番号」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc033/tasks/abc033_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
