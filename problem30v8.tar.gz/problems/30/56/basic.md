# 正直者か嘘つきか

## 問題

AtCoDeerくんとTopCoDeerくんが「正直者か嘘つきか」ゲームをしています。
このゲームでは、正直者は常にほんとうのことを言い、嘘つきは常に嘘を言います。

文字 `a` と `b` が与えられます。どちらも `"H"` または `"D"` です。

- `a` が `"H"` のとき、AtCoDeerくんは正直者です。
- `a` が `"D"` のとき、AtCoDeerくんは嘘つきです。
- `b` が `"H"` のとき、AtCoDeerくんは「TopCoDeerくんは正直者だ」と発言しています。
- `b` が `"D"` のとき、AtCoDeerくんは「TopCoDeerくんは嘘つきだ」と発言しています。

これらの情報から、TopCoDeerくんが正直者か嘘つきかを判定してください。

## 入力

`input` には、文字列 `a` と `b` を持つオブジェクトが入っています。

```json
{
  "a": "H",
  "b": "H"
}
```

`a` と `b` は、それぞれ `"H"` または `"D"` です。

## 出力

TopCoDeerくんが正直者なら `output` に `"H"` を代入してください。
嘘つきなら `output` に `"D"` を代入してください。

## 例

`input`:

```json
{
  "a": "H",
  "b": "H"
}
```

期待される `output`:

```json
"H"
```

AtCoDeerくんは正直者なので、発言どおりTopCoDeerくんは正直者です。

`input`:

```json
{
  "a": "D",
  "b": "H"
}
```

期待される `output`:

```json
"D"
```

AtCoDeerくんは嘘つきなので、発言とは異なりTopCoDeerくんは嘘つきです。

`input`:

```json
{
  "a": "D",
  "b": "D"
}
```

期待される `output`:

```json
"H"
```

## 出典

この問題は AtCoder Beginner Contest 056 A「HonestOrDishonest」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc056/tasks/abc056_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
