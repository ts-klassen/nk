# Debug

## 問題

英大文字のみからなる文字列 `S` を考えます。

`S` に対して、次の操作を繰り返します。

- 文字列が `WA` を連続する部分文字列として含むなら、文字列中に登場する `WA` のうち最も先頭のものを `AC` に置き換える。
- 文字列が `WA` を含まなくなったら、操作を終える。

この操作は必ず有限回で終了します。操作を終えた後に得られる文字列を求めてください。

## 入力

`input` には、英大文字のみからなる文字列 `S` が入っています。

`S` の長さは `1` 以上 `3 * 10^5` 以下です。

## 出力

`output` に、操作を終えた後に得られる文字列を代入してください。

## 例 1

`input`:

```json
"WACWA"
```

期待される `output`:

```json
"ACCAC"
```

## 例 2

`input`:

```json
"WWA"
```

期待される `output`:

```json
"ACC"
```

## 例 3

`input`:

```json
"WWWWW"
```

期待される `output`:

```json
"WWWWW"
```

## 出典

この問題は鹿島建設プログラミングコンテスト2025（AtCoder Beginner Contest 394）C「Debug」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc394/tasks/abc394_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
