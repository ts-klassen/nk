# アップルパイ

## 問題

林檎が `A` 個、林檎の欠片が `P` 個あります。

林檎 1 個は、砕くと林檎の欠片 3 個になります。また、林檎の欠片 2 個からアップルパイを 1 個作れます。

今ある材料で作れるアップルパイの最大個数を求めてください。

## 入力

`input` には、整数 `A` と `P` を持つオブジェクトが入っています。

- `A` は林檎の個数です。
- `P` は林檎の欠片の個数です。
- `0 <= A, P <= 100` です。

## 出力

`output` に、今ある材料で作れるアップルパイの最大個数を整数で代入してください。

## 例 1

`input`:

```json
{ "A": 1, "P": 3 }
```

期待される `output`:

```json
3
```

## 例 2

`input`:

```json
{ "A": 0, "P": 1 }
```

期待される `output`:

```json
0
```

## 例 3

`input`:

```json
{ "A": 32, "P": 21 }
```

期待される `output`:

```json
58
```

## 出典

この問題は AtCoder Beginner Contest 128 A「Apple Pie」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc128/tasks/abc128_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
