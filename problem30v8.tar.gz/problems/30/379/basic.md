# Cyclic

## 問題

整数 `N` の `100` の位を `a`、`10` の位を `b`、`1` の位を `c` とします。

`b,c,a` の順に桁を並べた整数と、`c,a,b` の順に桁を並べた整数を求めてください。

## 入力

`input` には、各桁が `1` 以上 `9` 以下である `3` 桁の整数 `N` が入っています。

## 出力

`output` には、`b,c,a` の順に桁を並べた整数と、`c,a,b` の順に桁を並べた整数を、この順に並べた配列を代入してください。

## 例 1

`input`:

```json
379
```

期待される `output`:

```json
[793, 937]
```

## 例 2

`input`:

```json
919
```

期待される `output`:

```json
[199, 991]
```

## 出典

この問題はトヨタ自動車プログラミングコンテスト2024#11(AtCoder Beginner Contest 379) A「Cyclic」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc379/tasks/abc379_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
