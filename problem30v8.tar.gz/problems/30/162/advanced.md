# 3つ組の最大公約数の総和

## 問題

整数 `K` が与えられます。

`1` 以上 `K` 以下の整数 `a`, `b`, `c` の組をすべて考え、それぞれの組について `a`, `b`, `c` の最大公約数を求めます。

すべての組について求めた最大公約数の合計を求めてください。

## 制約

- `1 <= K <= 200`
- `K` は整数

## 入力

`input` には整数 `K` が入っています。

## 出力

`output` に、すべての `1 <= a, b, c <= K` についての `gcd(a, b, c)` の合計を表す整数を代入してください。

## 例 1

`input`:

```json
2
```

期待される `output`:

```json
9
```

`1` 以上 `2` 以下の整数の組について最大公約数を足すと、
`1 + 1 + 1 + 1 + 1 + 1 + 1 + 2 = 9` になります。

## 例 2

`input`:

```json
200
```

期待される `output`:

```json
10813692
```

## 出典

この問題は AtCoder Beginner Contest 162 C「Sum of gcd of Tuples (Easy)」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc162/tasks/abc162_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
