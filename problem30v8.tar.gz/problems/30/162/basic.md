# Lucky 7

## 問題

3 桁の整数 `N` が与えられます。
`N` の百の位、十の位、一の位のどこかに数字 `7` が含まれているかを判定してください。

## 入力

`input` には、100 以上 999 以下の整数 `N` が入っています。

## 出力

`N` のいずれかの桁に数字 `7` が含まれる場合は、`output` に `"Yes"` を代入してください。
含まれない場合は、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
117
```

期待される `output`:

```json
"Yes"
```

`117` は一の位が `7` です。

## 例 2

`input`:

```json
123
```

期待される `output`:

```json
"No"
```

`123` はどの桁にも `7` を含みません。

## 例 3

`input`:

```json
777
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 162 A「Lucky 7」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc162/tasks/abc162_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
