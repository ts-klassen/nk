# FizzBuzz の数値の合計

## 問題

FizzBuzz 列 `a_1, a_2, ...` を次のように定めます。

- `i` が `3` でも `5` でも割り切れるなら、`a_i` は `"FizzBuzz"` です。
- そうではなく `i` が `3` で割り切れるなら、`a_i` は `"Fizz"` です。
- そうではなく `i` が `5` で割り切れるなら、`a_i` は `"Buzz"` です。
- そうではないなら、`a_i` は `i` です。

FizzBuzz 列の `N` 項目までに含まれる数の合計を求めてください。

## 入力

`input` には整数 `N` が入っています。

制約:

- `1 <= N <= 10^6`

## 出力

`output` に、FizzBuzz 列の `N` 項目までに含まれる数の合計を表す整数を代入してください。

## 例

`input`:

```json
15
```

期待される `output`:

```json
60
```

`15` 項目までは `1, 2, "Fizz", 4, "Buzz", "Fizz", 7, 8, "Fizz", "Buzz", 11, "Fizz", 13, 14, "FizzBuzz"` です。
この中に含まれる数は `1, 2, 4, 7, 8, 11, 13, 14` なので、合計は `60` です。

## 出典

この問題は AtCoder Beginner Contest 162 B「FizzBuzz Sum」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc162/tasks/abc162_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
