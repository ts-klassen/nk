# 景品の種類数

## 問題

くじ引きを `N` 回行いました。

`i` 回目には、種類が文字列 `S_i` で表される景品を手に入れました。

手に入れた景品は全部で何種類ありますか。

## 入力

`input` には、次の値を持つオブジェクトが入っています。

- `N`: くじ引きを行った回数
- `S`: 各回で手に入れた景品の種類を表す文字列の配列

`S` の長さは `N` です。

制約:

- `1 <= N <= 200000`
- `S_i` は英小文字だけからなる文字列
- `S_i` の長さは `1` 以上 `10` 以下

## 出力

`output` に、手に入れた景品の種類数を表す整数を代入してください。

## 例

`input`:

```json
{
  "N": 3,
  "S": ["apple", "orange", "apple"]
}
```

期待される `output`:

```json
2
```

`apple` と `orange` の `2` 種類の景品を手に入れています。

---

`input`:

```json
{
  "N": 5,
  "S": ["grape", "grape", "grape", "grape", "grape"]
}
```

期待される `output`:

```json
1
```

---

`input`:

```json
{
  "N": 4,
  "S": ["aaaa", "a", "aaa", "aa"]
}
```

期待される `output`:

```json
4
```

## 出典

この問題は AtCoder Beginner Contest 164 C「gacha」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc164/tasks/abc164_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
