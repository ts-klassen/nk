# 羊と狼

## 問題

羊が `S` 匹、狼が `W` 匹います。

狼の数が羊の数以上なら、羊は狼に襲われます。羊が襲われるかどうかを判定してください。

## 入力

`input` には、整数 `S` と `W` を持つオブジェクトが入っています。

- `S` は羊の数です。
- `W` は狼の数です。
- `1 <= S <= 100`
- `1 <= W <= 100`

## 出力

羊が狼に襲われるなら `output` に `"unsafe"` を代入してください。

襲われないなら `output` に `"safe"` を代入してください。

## 例 1

`input`:

```json
{ "S": 4, "W": 5 }
```

期待される `output`:

```json
"unsafe"
```

## 例 2

`input`:

```json
{ "S": 100, "W": 2 }
```

期待される `output`:

```json
"safe"
```

## 例 3

`input`:

```json
{ "S": 10, "W": 10 }
```

期待される `output`:

```json
"unsafe"
```

## 出典

この問題は AtCoder Beginner Contest 164 A「Sheep and Wolves」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc164/tasks/abc164_a
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
