# 3-smooth Numbers

## 問題

正の整数 `N` が与えられます。

`N = 2^x * 3^y` を満たす整数 `x`, `y` が存在するか判定してください。
存在するなら `"Yes"`、存在しないなら `"No"` を答えます。

## 入力

`input` には、正の整数 `N` の 10 進表記を表す文字列が入っています。

`N` は次の条件を満たします。

- `1 <= N <= 10^18`
- `N` は整数

範囲が大きいため、`input` は数値ではなく文字列で渡されます。

## 出力

`output` に `"Yes"` または `"No"` の文字列を代入してください。

## 例 1

`input`:

```json
"324"
```

期待される `output`:

```json
"Yes"
```

`x = 2`, `y = 4` とすると、`2^x * 3^y = 2^2 * 3^4 = 4 * 81 = 324` です。

## 例 2

`input`:

```json
"5"
```

期待される `output`:

```json
"No"
```

どのような整数 `x`, `y` を選んでも、`2^x * 3^y = 5` にはできません。

## 例 3

`input`:

```json
"32"
```

期待される `output`:

```json
"Yes"
```

`x = 5`, `y = 0` とすると、`2^x * 3^y = 32 * 1 = 32` です。

## 例 4

`input`:

```json
"37748736"
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は 日本レジストリサービス（JPRS）プログラミングコンテスト2023（AtCoder Beginner Contest 324） B「3-smooth Numbers」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc324/tasks/abc324_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
