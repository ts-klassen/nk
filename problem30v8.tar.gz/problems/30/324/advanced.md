# Error Correction

## 問題

高橋君が英小文字だけからなる文字列 `T` を送り、青木君は英小文字だけからなる文字列 `T'` を受け取りました。

受け取った文字列 `T'` は、送った文字列 `T` から次のいずれかの関係で得られることが分かっています。

- `T'` は `T` と等しい
- `T'` は `T` のどこか 1 か所に英小文字を 1 文字挿入して得られる
- `T'` は `T` から 1 文字を削除して得られる
- `T'` は `T` の 1 文字を別の英小文字に変更して得られる

受け取った文字列 `Tdash` と、候補文字列 `S_1, S_2, ..., S_N` が与えられます。
各 `S_i` を送った文字列 `T` だと考えたとき、`Tdash` が上の条件のどれかに当てはまるなら、`S_i` は候補です。

候補である `S_i` の添字をすべて求めてください。

## 入力

`input` には、次のプロパティを持つオブジェクトが入っています。

- `N`: 候補文字列の個数
- `Tdash`: 青木君が受け取った文字列 `T'`
- `S`: 候補文字列を順に並べた配列。長さは `N`

制約は次の通りです。

- `1 <= N <= 5 * 10^5`
- `Tdash` と各 `S_i` は英小文字からなる長さ 1 以上 `5 * 10^5` 以下の文字列
- `S_1, S_2, ..., S_N` の長さの総和は `5 * 10^5` 以下

## 出力

`output` に、候補である文字列の添字を昇順に並べた配列を代入してください。

添字は `S` の先頭を `1` として数えます。
候補が 1 つもない場合は、空配列 `[]` を代入してください。

## 例 1

`input`:

```json
{
  "N": 5,
  "Tdash": "ababc",
  "S": ["ababc", "babc", "abacbc", "abdbc", "abbac"]
}
```

期待される `output`:

```json
[1, 2, 3, 4]
```

## 例 2

`input`:

```json
{
  "N": 1,
  "Tdash": "aoki",
  "S": ["takahashi"]
}
```

期待される `output`:

```json
[]
```

## 例 3

`input`:

```json
{
  "N": 9,
  "Tdash": "atcoder",
  "S": [
    "atoder",
    "atcode",
    "athqcoder",
    "atcoder",
    "tacoder",
    "jttcoder",
    "atoder",
    "atceoder",
    "atcoer"
  ]
}
```

期待される `output`:

```json
[1, 2, 4, 7, 8, 9]
```

## 出典

この問題は 日本レジストリサービス（JPRS）プログラミングコンテスト2023（AtCoder Beginner Contest 324） C「Error Correction」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc324/tasks/abc324_c?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
