# すべて同じ値

## 問題

整数の個数 `N` と、長さ `N` の整数配列 `A` が与えられます。

`A` のすべての要素が同じ値なら `"Yes"`、そうでなければ `"No"` を答えてください。

制約は次の通りです。

- `2 <= N <= 100`
- `1 <= A[i] <= 100`
- `A` の長さは `N`

## 入力

`input` には、整数 `N` と配列 `A` を持つオブジェクトが入っています。

## 出力

`output` に `"Yes"` または `"No"` の文字列を代入してください。

## 例 1

`input`:

```json
{ "N": 3, "A": [3, 2, 4] }
```

期待される `output`:

```json
"No"
```

## 例 2

`input`:

```json
{ "N": 4, "A": [3, 3, 3, 3] }
```

期待される `output`:

```json
"Yes"
```

## 例 3

`input`:

```json
{ "N": 10, "A": [73, 8, 55, 26, 97, 48, 37, 47, 35, 55] }
```

期待される `output`:

```json
"No"
```

## 出典

この問題は 日本レジストリサービス（JPRS）プログラミングコンテスト2023（AtCoder Beginner Contest 324） A「Same」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc324/tasks/abc324_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
