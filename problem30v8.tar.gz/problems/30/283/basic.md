# A の B 乗

## 問題

整数 `A` と `B` が与えられます。

`A` の `B` 乗の値を求めてください。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

`A` と `B` はどちらも `1` 以上 `9` 以下です。

## 出力

`output` に、`A` の `B` 乗の値を数値として代入してください。

## 例

`input`:

```json
{ "A": 4, "B": 3 }
```

期待される `output`:

```json
64
```

`input`:

```json
{ "A": 5, "B": 5 }
```

期待される `output`:

```json
3125
```

`input`:

```json
{ "A": 8, "B": 1 }
```

期待される `output`:

```json
8
```

## 出典

この問題は AtCoder Beginner Contest 283 A「Power」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc283/tasks/abc283_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
