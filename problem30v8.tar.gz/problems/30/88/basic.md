# ちょうど払える硬貨

## 問題

E869120 は、1 円硬貨を `A` 枚と、500 円硬貨を何枚でも持っています。

これらの硬貨だけを使って、ちょうど `N` 円を支払えるか判定してください。

## 入力

`input` には、整数 `N` と `A` を持つオブジェクトが入っています。

- `N` は支払いたい金額です。
- `A` は持っている 1 円硬貨の枚数です。
- `N` は 1 以上 10000 以下です。
- `A` は 0 以上 1000 以下です。

## 出力

ちょうど `N` 円を支払えるなら、`output` に `"Yes"` を代入してください。
支払えないなら、`output` に `"No"` を代入してください。

## 例

`input`:

```json
{ "N": 2018, "A": 218 }
```

期待される `output`:

```json
"Yes"
```

500 円硬貨を 4 枚、1 円硬貨を 18 枚使うと、ちょうど 2018 円を支払えます。

`input`:

```json
{ "N": 2763, "A": 0 }
```

期待される `output`:

```json
"No"
```

1 円硬貨がないため、500 円の倍数の金額しか支払えません。

`input`:

```json
{ "N": 37, "A": 514 }
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 088 A「Infinite Coins」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc088/tasks/abc088_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
