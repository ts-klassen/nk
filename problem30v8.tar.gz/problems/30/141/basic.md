# 明日の天気

## 問題

高橋君の住む町の天気は、一日ごとに `Sunny`、`Cloudy`、`Rainy`、`Sunny`、`Cloudy`、`Rainy`、... という順で周期的に変化します。

今日の天気を表す文字列が与えられるので、明日の天気を求めてください。

## 入力

`input` には、今日の天気を表す文字列が入っています。

`input` は `"Sunny"`、`"Cloudy"`、`"Rainy"` のいずれかです。

## 出力

`output` に、明日の天気を表す文字列を代入してください。

## 例

`input`:

```json
"Sunny"
```

期待される `output`:

```json
"Cloudy"
```

`Sunny` の次の日の天気は `Cloudy` です。

## 出典

この問題は AtCoder Beginner Contest 141 A「Weather Prediction」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc141/tasks/abc141_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
