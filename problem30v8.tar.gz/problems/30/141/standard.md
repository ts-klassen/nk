# 踏みやすいタップダンス

## 問題

タップダンスの動きが文字列 `S` で表されています。
`S` の各文字は `L`, `R`, `U`, `D` のいずれかで、1 文字目から順番に足を置く位置を表します。

次の 2 つの条件を両方満たすとき、文字列 `S` は「踏みやすい」とします。

- 奇数文字目はすべて `R`, `U`, `D` のいずれかである。
- 偶数文字目はすべて `L`, `U`, `D` のいずれかである。

文字列 `S` が「踏みやすい」かどうかを判定してください。

## 入力

`input` には文字列 `S` が入っています。

`S` は次の条件を満たします。

- `S` の長さは 1 以上 100 以下である。
- `S` の各文字は `L`, `R`, `U`, `D` のいずれかである。

## 出力

`output` に、`S` が「踏みやすい」なら `"Yes"`、そうでなければ `"No"` を代入してください。

## 例

### 例 1

`input`:

```json
"RUDLUDR"
```

期待される `output`:

```json
"Yes"
```

### 例 2

`input`:

```json
"DULL"
```

期待される `output`:

```json
"No"
```

### 例 3

`input`:

```json
"UUUUUUUUUUUUUUU"
```

期待される `output`:

```json
"Yes"
```

### 例 4

`input`:

```json
"ULURU"
```

期待される `output`:

```json
"No"
```

### 例 5

`input`:

```json
"RDULULDURURLRDULRLR"
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 141 B「Tap Dance」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc141/tasks/abc141_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
