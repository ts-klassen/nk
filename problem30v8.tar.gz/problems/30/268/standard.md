# 接頭辞判定

## 問題

英小文字のみからなる 2 つの文字列 `S` と `T` があります。
`S` が `T` の接頭辞であるかを調べます。

接頭辞とは、ある文字列の先頭から何文字かを取り出した文字列です。
この課題では `S` の長さは 1 以上なので、`T` の先頭から `S` の長さぶん取り出した文字列が `S` と一致すれば、`S` は `T` の接頭辞です。
`S` と `T` が同じ文字列の場合も、`S` は `T` の接頭辞です。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

```json
{
  "S": "atco",
  "T": "atcoder"
}
```

`S` と `T` はそれぞれ英小文字のみからなる、長さ 1 以上 100 以下の文字列です。

## 出力

`S` が `T` の接頭辞であれば、`output` に `"Yes"` を代入してください。
そうでなければ、`output` に `"No"` を代入してください。
`"Yes"` と `"No"` は、大文字と小文字を区別してそのまま使います。

## 例

### 例 1

`input`:

```json
{
  "S": "atco",
  "T": "atcoder"
}
```

期待される `output`:

```json
"Yes"
```

### 例 2

`input`:

```json
{
  "S": "code",
  "T": "atcoder"
}
```

期待される `output`:

```json
"No"
```

### 例 3

`input`:

```json
{
  "S": "abc",
  "T": "abc"
}
```

期待される `output`:

```json
"Yes"
```

### 例 4

`input`:

```json
{
  "S": "aaaa",
  "T": "aa"
}
```

期待される `output`:

```json
"No"
```

## 出典

この問題は ユニークビジョンプログラミングコンテスト2022 夏(AtCoder Beginner Contest 268) B「Prefix?」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc268/tasks/abc268_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
