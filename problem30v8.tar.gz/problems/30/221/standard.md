# 隣り合う文字の入れ替え

## 問題

文字列 `S` と `T` が与えられます。
`S` に対して、次の操作を高々 1 回だけ行えます。

- `S` の隣り合う 2 文字を選び、入れ替える。

操作を行わないこともできます。
操作後の `S` を `T` と一致させられるか判定してください。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

```json
{ "S": "abc", "T": "acb" }
```

`S` と `T` は以下を満たします。

- `S` と `T` は英小文字のみからなる文字列です。
- `S` と `T` の長さは等しく、2 以上 100 以下です。

## 出力

`output` に、`S` を `T` と一致させられるなら `"Yes"`、一致させられないなら `"No"` の文字列を代入してください。

## 例

### 例 1

`input`:

```json
{ "S": "abc", "T": "acb" }
```

期待される `output`:

```json
"Yes"
```

`S` の 2 文字目と 3 文字目を入れ替えると、`T` と一致します。

### 例 2

`input`:

```json
{ "S": "aabb", "T": "bbaa" }
```

期待される `output`:

```json
"No"
```

どの隣り合う 2 文字を入れ替えても、`T` と一致しません。

### 例 3

`input`:

```json
{ "S": "abcde", "T": "abcde" }
```

期待される `output`:

```json
"Yes"
```

`S` と `T` はすでに一致しています。

## 出典

この問題は AtCoder Beginner Contest 221 B「typo」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc221/tasks/abc221_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
