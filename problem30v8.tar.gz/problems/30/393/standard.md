# 等間隔の A, B, C

## 問題

文字列 `S` の中から、3 つの位置 `i`, `j`, `k` を選びます。

位置は 1 文字目から数えるものとします。次の条件をすべて満たす組 `(i, j, k)` が何個あるか求めてください。

- `1 <= i < j < k <= S.length`
- `j - i = k - j`
- `S` の `i` 文字目は `A`
- `S` の `j` 文字目は `B`
- `S` の `k` 文字目は `C`

## 入力

`input` には、英大文字からなる文字列 `S` が入っています。

`S` の長さは 3 以上 100 以下です。

## 出力

`output` に、条件を満たす組 `(i, j, k)` の個数を整数で代入してください。

## 例

### 例 1

`input`:

```json
"AABCC"
```

期待される `output`:

```json
2
```

条件を満たす組は `(1, 3, 5)` と `(2, 3, 4)` の 2 個です。

### 例 2

`input`:

```json
"ARC"
```

期待される `output`:

```json
0
```

### 例 3

`input`:

```json
"AABAAABBAEDCCCD"
```

期待される `output`:

```json
4
```

## 出典

この問題は AtCoder Beginner Contest 393 B「A..B..C」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc393/tasks/abc393_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
