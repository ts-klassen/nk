# 二乗和との差の最小値

## 問題

正整数 `D` が与えられます。

非負整数 `x`, `y` を自由に選ぶとき、`|x^2 + y^2 - D|` の最小値を求めてください。

## 入力

`input` には整数 `D` が入っています。

- `1 <= D <= 2 * 10^12`

## 出力

`output` に、非負整数 `x`, `y` に対する `|x^2 + y^2 - D|` の最小値を表す整数を代入してください。

## 例

`input`:

```json
21
```

期待される `output`:

```json
1
```

`x = 4`, `y = 2` とすると、`|4^2 + 2^2 - 21| = 1` になります。差を `0` にできる組はないため、最小値は `1` です。

## 例 2

`input`:

```json
998244353
```

期待される `output`:

```json
0
```

## 例 3

`input`:

```json
264428617
```

期待される `output`:

```json
32
```

## 出典

この問題は トヨタシステムズプログラミングコンテスト2023(AtCoder Beginner Contest 330) C「Minimize Abs 2」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc330/tasks/abc330_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
