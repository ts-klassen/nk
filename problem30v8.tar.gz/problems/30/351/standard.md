# 異なるマスを探す

## 問題

縦 `N` マス、横 `N` マスの 2 つのグリッド `A` と `B` が与えられます。
それぞれのマスには英小文字が 1 つずつ書かれています。

`A` と `B` は、ちょうど 1 つのマスだけ文字が異なります。
そのマスが上から何行目、左から何列目にあるかを求めてください。

行と列はどちらも `1` から数えます。

## 入力

`input` には、次のプロパティを持つオブジェクトが入っています。

- `N`: グリッドの縦横の大きさを表す整数
- `A`: グリッド `A` を表す、長さ `N` の文字列の配列
- `B`: グリッド `B` を表す、長さ `N` の文字列の配列

`1 <= N <= 100` です。
`A` と `B` の各文字列の長さは `N` で、すべて英小文字からなります。
`A` と `B` で文字が異なるマスはちょうど 1 つです。

## 出力

`output` に、文字が異なるマスの行番号と列番号をこの順に並べた配列 `[i, j]` を代入してください。

## 例 1

`input`:

```json
{
  "N": 3,
  "A": ["abc", "def", "ghi"],
  "B": ["abc", "bef", "ghi"]
}
```

期待される `output`:

```json
[2, 1]
```

## 例 2

`input`:

```json
{
  "N": 1,
  "A": ["f"],
  "B": ["q"]
}
```

期待される `output`:

```json
[1, 1]
```

## 例 3

`input`:

```json
{
  "N": 10,
  "A": [
    "eixfumagit",
    "vtophbepfe",
    "pxbfgsqcug",
    "ugpugtsxzq",
    "bvfhxyehfk",
    "uqyfwtmglr",
    "jaitenfqiq",
    "acwvufpfvv",
    "jhaddglpva",
    "aacxsyqvoj"
  ],
  "B": [
    "eixfumagit",
    "vtophbepfe",
    "pxbfgsqcug",
    "ugpugtsxzq",
    "bvfhxyehok",
    "uqyfwtmglr",
    "jaitenfqiq",
    "acwvufpfvv",
    "jhaddglpva",
    "aacxsyqvoj"
  ]
}
```

期待される `output`:

```json
[5, 9]
```

## 出典

この問題は AtCoder Beginner Contest 351 B「Spot the Difference」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc351/tasks/abc351_b?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
