# 中央のドア

## 問題

整数 `N` が与えられます。

次の条件をすべて満たす、長さ `N` の文字列を作ってください。

- 各文字は `-` または `=` である。
- 回文である。
- 文字列の中に `=` は 1 個または 2 個含まれる。
- `=` が 2 個含まれる場合、その 2 個は隣り合っている。

この条件を満たす文字列は、ちょうど 1 つだけ存在します。

## 入力

`input` には整数 `N` が入っています。

制約:

- `1 <= N <= 100`
- `N` は整数

## 出力

`output` に、条件をすべて満たす文字列を代入してください。

## 例 1

`input`:

```json
4
```

期待される `output`:

```json
"-==-"
```

## 例 2

`input`:

```json
7
```

期待される `output`:

```json
"---=---"
```

## 出典

この問題はユニークビジョンプログラミングコンテスト2025 春（AtCoder Beginner Contest 398）A「Doors in the Center」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc398/tasks/abc398_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
