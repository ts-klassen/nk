# 借金を倍にして返す

## 問題

高橋君は `N` 円借金をしました。

倍返しでおもてなしするのが流行だと聞いた高橋君は、借りた金額の 2 倍を返済します。

高橋君が返済する金額を求めてください。

## 入力

`input` には、高橋君が借金した金額を表す整数 `N` が入っています。

`N` は `0 <= N <= 10^6` を満たします。

## 出力

`output` に、高橋君が返済する金額 `2 * N` を表す整数を代入してください。

## 例

`input`:

```json
1000
```

期待される `output`:

```json
2000
```

`input`:

```json
1000000
```

期待される `output`:

```json
2000000
```

`input`:

```json
0
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 004 A「流行」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc004/tasks/abc004_1?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
