# 盤面の 180 度回転

## 問題

4 x 4 マスの盤面があります。各マスには `.`, `o`, `x` のいずれかの文字が書かれています。

この盤面を正面から見て 180 度回転させた後の盤面を求めてください。

## 入力

`input` には、`board` というプロパティを持つオブジェクトが入っています。

`board` は長さ 4 の配列で、各要素は長さ 4 の文字列です。`board[i][j]` は上から `i + 1` 行目、左から `j + 1` 列目のマスを表し、`.`、`o`、`x` のいずれかの文字です。

## 出力

`output` に、180 度回転させた後の盤面を長さ 4 の文字列の配列として代入してください。

## 例 1

`input`:

```json
{
  "board": ["....", ".oo.", ".xx.", "...."]
}
```

期待される `output`:

```json
["....", ".xx.", ".oo.", "...."]
```

## 例 2

`input`:

```json
{
  "board": ["ooxx", "ooxx", "xxoo", "xxoo"]
}
```

期待される `output`:

```json
["ooxx", "ooxx", "xxoo", "xxoo"]
```

## 出典

この問題は AtCoder Beginner Contest 004 B「回転」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc004/tasks/abc004_2?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
