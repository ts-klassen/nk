# 回転

## 問題

`N × N` のマス目があります。
各マスには `"o"` または `"x"` の文字が書かれています。

このマス目を時計回りに 90 度回転してください。

## 入力

`input` には、整数 `N` と文字列配列 `S` を持つオブジェクトが入っています。

`S` の長さは `N` です。
各文字列の長さも `N` で、それぞれの文字は `"o"` または `"x"` です。

制約は次の通りです。

- `1 <= N <= 50`
- `S` の各文字は `"o"` または `"x"`

## 出力

`output` に、回転後のマス目を上の行から順に並べた文字列配列を代入してください。
配列の長さは `N`、各文字列の長さも `N` にしてください。

## 例

`input`:

```json
{
  "N": 4,
  "S": ["ooxx", "xoox", "xxxx", "xxxx"]
}
```

期待される `output`:

```json
["xxxo", "xxoo", "xxox", "xxxx"]
```

## 出典

この問題は AtCoder Beginner Contest 036 B「回転」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc036/tasks/abc036_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
