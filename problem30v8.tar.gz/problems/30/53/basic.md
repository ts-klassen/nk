# ABC/ARC

## 問題

すめけくんは、現在のレートが `1200` 未満なら AtCoder Beginner Contest (ABC) に、`1200` 以上なら AtCoder Regular Contest (ARC) に参加します。

すめけくんの現在のレート `x` が与えられます。参加するコンテストが ABC なら `"ABC"`、ARC なら `"ARC"` を求めてください。

## 入力

`input` には、整数 `x` が入っています。

制約:

- `1 <= x <= 3000`
- `x` は整数

## 出力

`output` に `"ABC"` または `"ARC"` の文字列を代入してください。

## 例

`input`:

```json
1000
```

期待される `output`:

```json
"ABC"
```

`input`:

```json
2000
```

期待される `output`:

```json
"ARC"
```

## 出典

この問題は AtCoder Beginner Contest 053 A「ABC/ARC」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc053/tasks/abc053_a
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
