# A から Z までの長さ

## 問題

英大文字だけからなる文字列 `input` が与えられます。

`input` の連続した一部分のうち、先頭が `"A"` で末尾が `"Z"` である文字列を考えます。
そのような文字列として作ることができる最大の長さを求めてください。

`input` には、先頭が `"A"` で末尾が `"Z"` である連続部分が必ず存在します。

## 入力

`input` には、英大文字だけからなる文字列が入っています。

制約:

- `1 <= input.length <= 200000`
- `input` は英大文字のみからなる
- `input` には、先頭が `"A"` で末尾が `"Z"` である連続部分が必ず存在する

## 出力

`output` に、条件を満たす連続部分の最大の長さを表す整数を代入してください。

## 例 1

`input`:

```json
"QWERTYASDFZXCV"
```

期待される `output`:

```json
5
```

7 文字目から 11 文字目までの `"ASDFZ"` が条件を満たします。

## 例 2

`input`:

```json
"ZABCZ"
```

期待される `output`:

```json
4
```

## 例 3

`input`:

```json
"HASFJGHOGAKZZFEGA"
```

期待される `output`:

```json
12
```

## 出典

この問題は AtCoder Beginner Contest 053 B「A to Z String」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc053/tasks/abc053_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
