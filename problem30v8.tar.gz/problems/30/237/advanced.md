# 先頭に a を足して回文にする

## 問題

英小文字だけからなる文字列 `S` があります。

`S` の先頭に文字 `"a"` を 0 個以上追加して、できあがった文字列を回文にできるか判定してください。

回文とは、前から読んでも後ろから読んでも同じ文字列のことです。

`S` の長さは 1 以上 1,000,000 以下です。

## 入力

`input` には、英小文字だけからなる文字列 `S` が入っています。

## 出力

先頭に文字 `"a"` を 0 個以上追加して回文にできるなら、`output` に `"Yes"` を代入してください。
できないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
"kasaka"
```

期待される `output`:

```json
"Yes"
```

`"kasaka"` の先頭に `"a"` を 1 つ追加すると `"akasaka"` になり、回文です。

## 例 2

`input`:

```json
"atcoder"
```

期待される `output`:

```json
"No"
```

`"atcoder"` の先頭に `"a"` をいくつ追加しても、回文にはできません。

## 例 3

`input`:

```json
"php"
```

期待される `output`:

```json
"Yes"
```

`"php"` はそのままで回文です。追加する `"a"` は 0 個でもかまいません。

## 出典

この問題は AtCoder Beginner Contest 237 C「kasaka」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc237/tasks/abc237_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
