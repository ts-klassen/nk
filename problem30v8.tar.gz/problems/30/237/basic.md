# 32ビット整数の範囲判定

## 問題

整数 `N` が与えられます。

`N` が `-2147483648` 以上かつ `2147483648` 未満なら `"Yes"`、そうでなければ `"No"` を答えてください。

## 入力

`input` には整数 `N` がそのまま入っています。

`N` は `-2^63` 以上かつ `2^63` 未満の整数です。

## 出力

`output` に `"Yes"` または `"No"` の文字列を代入してください。

## 例 1

`input`:

```json
10
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
-9876543210
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
483597848400000
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 237 A「Not Overflow」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc237/tasks/abc237_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
