# 起床時刻の比較

## 問題

ある日、高橋君は `A` 時 `B` 分ちょうどに起きました。
青木君は `C` 時 `D` 分 1 秒に起きました。

高橋君の起床時刻が青木君より早いかどうかを判定してください。
時刻は同じ日の 24 時間表記として比べます。

## 入力

`input` には、整数 `A`、`B`、`C`、`D` を持つオブジェクトが入っています。

- `A` と `C` は時を表し、`0` 以上 `23` 以下です。
- `B` と `D` は分を表し、`0` 以上 `59` 以下です。
- 高橋君の起床時刻は `A` 時 `B` 分 0 秒です。
- 青木君の起床時刻は `C` 時 `D` 分 1 秒です。

## 出力

高橋君の起床時刻が青木君より早いなら、`output` に `"Takahashi"` を代入してください。
そうでないなら、`output` に `"Aoki"` を代入してください。

## 例 1

`input`:

```json
{ "A": 7, "B": 0, "C": 6, "D": 30 }
```

期待される `output`:

```json
"Aoki"
```

## 例 2

`input`:

```json
{ "A": 7, "B": 30, "C": 7, "D": 30 }
```

期待される `output`:

```json
"Takahashi"
```

## 例 3

`input`:

```json
{ "A": 0, "B": 0, "C": 23, "D": 59 }
```

期待される `output`:

```json
"Takahashi"
```

## 出典

この問題は AtCoder Beginner Contest 245 A「Good morning」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc245/tasks/abc245_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
