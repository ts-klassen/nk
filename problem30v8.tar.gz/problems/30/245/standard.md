# Mex

## 問題

整数 `N` と、長さ `N` の整数配列 `A` が与えられます。

`A` に含まれない最小の非負整数を求めてください。

制約:

- `1 <= N <= 2000`
- `0 <= A[i] <= 2000`
- `A` の長さは `N`

## 入力

`input` には、整数 `N` と整数配列 `A` を持つオブジェクトが入っています。

## 出力

`output` に、`A` に含まれない最小の非負整数を代入してください。

## 例 1

`input`:

```json
{
  "N": 8,
  "A": [0, 3, 2, 6, 2, 1, 0, 0]
}
```

期待される `output`:

```json
4
```

`0`, `1`, `2`, `3` は `A` に含まれ、`4` は含まれないため、答えは `4` です。

## 例 2

`input`:

```json
{
  "N": 3,
  "A": [2000, 2000, 2000]
}
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 245 B「Mex」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc245/tasks/abc245_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
