# ベルトコンベアの終点

## 問題

縦 `H` 行、横 `W` 列のマス目があります。上から `i` 行目、左から `j` 列目のマスを `(i, j)` とします。

各マスには、`"U"`、`"D"`、`"L"`、`"R"` のいずれか 1 文字が書かれています。あなたは最初に `(1, 1)` にいます。

現在いるマスの文字にしたがって、次のように移動します。

- `"U"` なら 1 つ上のマスへ移動します。ただし、すでに 1 行目にいる場合は移動できません。
- `"D"` なら 1 つ下のマスへ移動します。ただし、すでに `H` 行目にいる場合は移動できません。
- `"L"` なら 1 つ左のマスへ移動します。ただし、すでに 1 列目にいる場合は移動できません。
- `"R"` なら 1 つ右のマスへ移動します。ただし、すでに `W` 列目にいる場合は移動できません。

移動できなくなったときにいるマスを求めてください。移動が終わらず、同じ動きを無限に繰り返す場合は `-1` とします。

## 入力

`input` には、次の形式のオブジェクトが入っています。

```json
{
  "H": 2,
  "W": 3,
  "G": ["RDU", "LRU"]
}
```

- `H` はマス目の行数です。
- `W` はマス目の列数です。
- `G` は長さ `H` の配列です。`G[i - 1][j - 1]` が、マス `(i, j)` に書かれた文字を表します。

制約は次の通りです。

- `1 <= H, W <= 500`
- `G` の各文字は `"U"`、`"D"`、`"L"`、`"R"` のいずれかです。

## 出力

移動できなくなったときに `(i, j)` にいるなら、`output` に `[i, j]` を代入してください。

無限に移動し続ける場合は、`output` に `-1` を代入してください。

## 例

`input`:

```json
{
  "H": 2,
  "W": 3,
  "G": ["RDU", "LRU"]
}
```

期待される `output`:

```json
[1, 3]
```

`(1, 1) -> (1, 2) -> (2, 2) -> (2, 3) -> (1, 3)` と移動し、その先には進めません。

`input`:

```json
{
  "H": 2,
  "W": 3,
  "G": ["RRD", "ULL"]
}
```

期待される `output`:

```json
-1
```

この場合、同じマスを繰り返し通るため移動が終わりません。

`input`:

```json
{
  "H": 9,
  "W": 44,
  "G": [
    "RRDDDDRRRDDDRRRRRRDDDRDDDDRDDRDDDDDDRRDRRRRR",
    "RRRDLRDRDLLLLRDRRLLLDDRDLLLRDDDLLLDRRLLLLLDD",
    "DRDLRLDRDLRDRLDRLRDDLDDLRDRLDRLDDRLRRLRRRDRR",
    "DDLRRDLDDLDDRLDDLDRDDRDDDDRLRRLRDDRRRLDRDRDD",
    "RDLRRDLRDLLLLRRDLRDRRDRRRDLRDDLLLLDDDLLLLRDR",
    "RDLLLLLRDLRDRLDDLDDRDRRDRLDRRRLDDDLDDDRDDLDR",
    "RDLRRDLDDLRDRLRDLDDDLDDRLDRDRDLDRDLDDLRRDLRR",
    "RDLDRRLDRLLLLDRDRLLLRDDLLLLLRDRLLLRRRRLLLDDR",
    "RRRRDRDDRRRDDRDDDRRRDRDRDRDRRRRRRDDDRDDDDRRR"
  ]
}
```

期待される `output`:

```json
[9, 5]
```

## 出典

この問題は AtCoder Beginner Contest 265 C「Belt Conveyor」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc265/tasks/abc265_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
