# 土曜日まであと何日

## 問題

ある日、学校へ行くのに疲れてしまった高橋くんは、土曜日まであと何日あるかを知りたくなりました。

その日は平日で、曜日を英語で表すと `S` でした。その日より後の直近の土曜日は何日後かを求めてください。

月曜日、火曜日、水曜日、木曜日、金曜日は、それぞれ `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday` です。

## 入力

`input` には、文字列 `S` が入っています。

`S` は `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday` のいずれかです。

## 出力

`output` に、その日より後の直近の土曜日までの日数を整数で代入してください。

## 例

`input`:

```json
"Wednesday"
```

期待される `output`:

```json
3
```

この日は水曜日なので、3 日後に土曜日になります。

`input`:

```json
"Monday"
```

期待される `output`:

```json
5
```

## 出典

この問題は NECプログラミングコンテスト2022 (AtCoder Beginner Contest 267) A「Saturday」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc267/tasks/abc267_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
