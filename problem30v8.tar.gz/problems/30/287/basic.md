# 過半数の賛成

## 問題

ある提案に対し、`N` 人の人が賛成か反対かを表明しています。`N` は奇数です。

`i` 番目の人の意見は文字列 `S_i` で表され、`"For"` のとき賛成、`"Against"` のとき反対です。

過半数の人がこの提案に賛成しているかどうかを判定してください。

## 入力

`input` には、次のプロパティを持つオブジェクトが入っています。

- `N`: 人数を表す整数。`1` 以上 `99` 以下の奇数です。
- `S`: 長さ `N` の文字列配列です。各要素は `"For"` または `"Against"` です。

## 出力

`N` 人のうち過半数が提案に賛成しているなら `output` に `"Yes"` を代入してください。そうでなければ `output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{
  "N": 3,
  "S": ["For", "Against", "For"]
}
```

期待される `output`:

```json
"Yes"
```

提案に賛成している人数は `2` 人であり、これは半数を超えています。

## 例 2

`input`:

```json
{
  "N": 5,
  "S": ["Against", "Against", "For", "Against", "For"]
}
```

期待される `output`:

```json
"No"
```

提案に賛成している人数は `2` 人であり、これは半数以下です。

## 例 3

`input`:

```json
{
  "N": 1,
  "S": ["For"]
}
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は ユニークビジョンプログラミングコンテスト2023 新春 (AtCoder Beginner Contest 287) A「Majority」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc287/tasks/abc287_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
