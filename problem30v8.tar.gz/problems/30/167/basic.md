# 登録 ID の確認

## 問題

高橋君は、ある Web サービスに会員登録しようとしています。

はじめに ID として `S` を使おうとしましたが、この ID はすでに使われていました。そこで、`S` の末尾に英小文字を 1 文字追加した文字列を、新しい ID として使うことにしました。

高橋君が新しく使おうとしている ID は `T` です。`T` が条件を満たしているか判定してください。

## 入力

`input` には、英小文字列 `S` と `T` を持つオブジェクトが入っています。

`S` の長さは 1 文字以上 10 文字以下で、`T` の長さは `S` より 1 文字だけ長いです。

## 出力

`T` が `S` の末尾に 1 文字追加して得られる文字列なら、`output` に `"Yes"` を代入してください。

そうでないなら、`output` に `"No"` を代入してください。

## 例

### 例 1

`input`:

```json
{
  "S": "chokudai",
  "T": "chokudaiz"
}
```

期待される `output`:

```json
"Yes"
```

### 例 2

`input`:

```json
{
  "S": "snuke",
  "T": "snekee"
}
```

期待される `output`:

```json
"No"
```

### 例 3

`input`:

```json
{
  "S": "a",
  "T": "aa"
}
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 167 A「Registration」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc167/tasks/abc167_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
