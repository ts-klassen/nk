# 対になる塩基

## 問題

AtCoder 星には、`A`、`C`、`G`、`T` の 4 種類の塩基があります。

`A` と `T`、`C` と `G` は、それぞれ対になります。

塩基を表す 1 文字が与えられるので、それと対になる塩基を求めてください。

## 入力

`input` には、文字列 `b` が入っています。

`b` は `"A"`、`"C"`、`"G"`、`"T"` のいずれかです。

## 出力

`output` に、`b` と対になる塩基を表す文字列を代入してください。

## 例

`input`:

```json
"A"
```

期待される `output`:

```json
"T"
```

`input`:

```json
"G"
```

期待される `output`:

```json
"C"
```

## 出典

この問題は AtCoder Beginner Contest 122 A「Double Helix」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc122/tasks/abc122_a
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
