# ACGT 文字列

## 問題

英大文字からなる文字列 `S` が与えられます。

`S` の連続する一部分のうち、文字 `A`、`C`、`G`、`T` だけでできているものを考えます。そのような文字列の長さとして、最大の値を求めてください。

例えば、`ATCODER` の連続する一部分には `ATC` や `TCO` や `CODER` などがあります。このうち `A`、`C`、`G`、`T` だけでできている最長のものは `ATC` です。

制約:

- `S` は長さ 1 以上 10 以下の文字列です。
- `S` の各文字は英大文字です。

## 入力

`input` には、英大文字からなる文字列 `S` が入っています。

## 出力

`output` に、`S` の連続する一部分であり、かつ文字 `A`、`C`、`G`、`T` だけでできている文字列の最長の長さを表す整数を代入してください。

## 例

`input`:

```json
"ATCODER"
```

期待される `output`:

```json
3
```

`input`:

```json
"HATAGAYA"
```

期待される `output`:

```json
5
```

`input`:

```json
"SHINJUKU"
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 122 B「ATCoder」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc122/tasks/abc122_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
