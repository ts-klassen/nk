# 次の日曜日までの日数

## 問題

今日の曜日を表す文字列が与えられます。

文字列は `"SUN"`, `"MON"`, `"TUE"`, `"WED"`, `"THU"`, `"FRI"`, `"SAT"` のいずれかで、それぞれ日曜日、月曜日、火曜日、水曜日、木曜日、金曜日、土曜日を表します。

次の日曜日が何日後かを求めてください。ただし、今日が日曜日の場合は、次の日曜日は 7 日後です。

## 入力

`input` には、今日の曜日を表す文字列が入っています。

## 出力

`output` に、次の日曜日が何日後かを表す整数を代入してください。

## 例

`input`:

```json
"SAT"
```

期待される `output`:

```json
1
```

`input`:

```json
"SUN"
```

期待される `output`:

```json
7
```

## 出典

この問題は AtCoder Beginner Contest 146 A「Can't Wait for Holiday」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc146/tasks/abc146_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
