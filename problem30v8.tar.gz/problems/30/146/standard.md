# ROT N

## 問題

英大文字だけからなる文字列 `S` と、整数 `N` が与えられます。

`S` の各文字を、アルファベット順で `N` 個後ろの文字に置き換えた文字列を作ってください。ただし、`Z` の次は `A` として、アルファベットは循環するものとします。

## 入力

`input` には、整数 `N` と文字列 `S` を持つオブジェクトが入っています。

- `0 <= N <= 26`
- `1 <= S.length <= 10000`
- `S` は英大文字のみからなる文字列

## 出力

`output` に、`S` の各文字をアルファベット順で `N` 個後ろの文字に置き換えた文字列を代入してください。

## 例 1

`input`:

```json
{
  "N": 2,
  "S": "ABCXYZ"
}
```

期待される `output`:

```json
"CDEZAB"
```

## 例 2

`input`:

```json
{
  "N": 0,
  "S": "ABCXYZ"
}
```

期待される `output`:

```json
"ABCXYZ"
```

## 例 3

`input`:

```json
{
  "N": 13,
  "S": "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
}
```

期待される `output`:

```json
"NOPQRSTUVWXYZABCDEFGHIJKLM"
```

## 出典

この問題は AtCoder Beginner Contest 146 B「ROT N」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc146/tasks/abc146_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
