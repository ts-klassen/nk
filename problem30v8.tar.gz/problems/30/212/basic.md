# 金属の種類

## 問題

高橋くんは、`A` グラムの純金と `B` グラムの純銀をよく溶かして混ぜ合わせ、新しい金属を作りました。

作られた金属を次のルールで判定してください。

- `A` が 0 より大きく、`B` が 0 のとき、金属は純金です。
- `A` が 0 で、`B` が 0 より大きいとき、金属は純銀です。
- `A` も `B` も 0 より大きいとき、金属は合金です。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

`A` は純金のグラム数、`B` は純銀のグラム数です。

```json
{
  "A": 50,
  "B": 50
}
```

`A` と `B` は次の条件を満たします。

- `0 <= A <= 100`
- `0 <= B <= 100`
- `0 < A + B`

## 出力

`output` に、作られた金属を表す文字列を代入してください。

- 純金なら `"Gold"`
- 純銀なら `"Silver"`
- 合金なら `"Alloy"`

## 例

`input`:

```json
{
  "A": 50,
  "B": 50
}
```

期待される `output`:

```json
"Alloy"
```

`input`:

```json
{
  "A": 100,
  "B": 0
}
```

期待される `output`:

```json
"Gold"
```

`input`:

```json
{
  "A": 0,
  "B": 100
}
```

期待される `output`:

```json
"Silver"
```

`input`:

```json
{
  "A": 100,
  "B": 2
}
```

期待される `output`:

```json
"Alloy"
```

## 出典

この問題は AtCoder Beginner Contest 212 A「Alloy」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc212/tasks/abc212_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
