# 奇数になる確率

## 問題

整数 `N` が与えられます。

高橋君は、`N` 以下の正整数の中から等確率で 1 つを選び、それを `a` とします。

`a` が奇数である確率を求めてください。

## 入力

`input` には整数 `N` が入っています。

`N` は 1 以上 100 以下です。

## 出力

`output` に、`a` が奇数である確率を表す数値を代入してください。

## 例 1

`input`:

```json
4
```

期待される `output`:

```json
0.5
```

4 以下の正整数は `1`, `2`, `3`, `4` の 4 つで、そのうち奇数は `1`, `3` の 2 つです。

## 例 2

`input`:

```json
5
```

期待される `output`:

```json
0.6
```

## 例 3

`input`:

```json
1
```

期待される `output`:

```json
1
```

## 出典

この問題は AtCoder Beginner Contest 142 A「Odds of Oddness」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc142/tasks/abc142_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
