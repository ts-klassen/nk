# 読みにくい文字列

## 問題

文字列について、先頭から数えて奇数番目の文字がすべて英小文字で、偶数番目の文字がすべて英大文字であるとき、その文字列を「読みにくい文字列」とします。

与えられた文字列 `S` が、読みにくい文字列かどうかを判定してください。

## 入力

`input` には、英大文字と英小文字だけからなる文字列 `S` が入っています。

`S` の長さは 1 以上 1000 以下です。

## 出力

`S` が読みにくい文字列なら `output` に `"Yes"` を、そうでなければ `"No"` を代入してください。

## 例 1

`input`:

```json
"dIfFiCuLt"
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
"eASY"
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
"a"
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は SOMPO HD プログラミングコンテスト2021(AtCoder Beginner Contest 192) B「uNrEaDaBlE sTrInG」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc192/tasks/abc192_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
