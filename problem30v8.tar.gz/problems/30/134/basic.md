# 正十二角形の面積

## 問題

半径 `a` の円に内接する正十二角形の面積は `3 * a * a` で求められます。

整数 `r` が与えられるので、半径 `r` の円に内接する正十二角形の面積を求めてください。

制約:

- `1 <= r <= 100`
- `r` は整数

## 入力

`input` には整数 `r` が入っています。

## 出力

`output` に、正十二角形の面積を表す整数を代入してください。

## 例

`input`:

```json
4
```

期待される `output`:

```json
48
```

この場合、正十二角形の面積は `3 * 4 * 4 = 48` です。

## 出典

この問題は AtCoder Beginner Contest 134 A「Dodecagon」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc134/tasks/abc134_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
