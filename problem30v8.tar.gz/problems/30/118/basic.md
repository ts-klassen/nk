# 約数なら足し算

## 問題

正整数 `A` と `B` が与えられます。

`A` が `B` の約数であるときは `A + B` を、そうでないときは `B - A` を求めてください。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

```json
{
  "A": 4,
  "B": 12
}
```

`A` と `B` はどちらも整数で、`1 <= A <= B <= 20` を満たします。

## 出力

`output` に、条件に応じて計算した整数を代入してください。

`A` が `B` の約数であるときは `A + B`、そうでないときは `B - A` が答えです。

## 例

`input`:

```json
{
  "A": 4,
  "B": 12
}
```

期待される `output`:

```json
16
```

`4` は `12` の約数なので、答えは `4 + 12 = 16` です。

## 出典

この問題は AtCoder Beginner Contest 118 A「B +/- A」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc118/tasks/abc118_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
