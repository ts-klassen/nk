# Takahashi の数を数える

## 問題

文字列が `N` 個あります。

`i` 番目の文字列 `S_i` は、`"Takahashi"` または `"Aoki"` のどちらかです。

`S_i` が `"Takahashi"` と等しい `i` がいくつあるか求めてください。

## 入力

`input` には、整数 `N` と文字列の配列 `S` を持つオブジェクトが入っています。

`S` の長さは `N` で、各要素は `"Takahashi"` または `"Aoki"` です。

制約:

- `1 <= N <= 100`
- `N` は整数

## 出力

`output` に、`S` の中で `"Takahashi"` と等しい要素の個数を整数として代入してください。

## 例 1

`input`:

```json
{
  "N": 3,
  "S": ["Aoki", "Takahashi", "Takahashi"]
}
```

期待される `output`:

```json
2
```

## 例 2

`input`:

```json
{
  "N": 2,
  "S": ["Aoki", "Aoki"]
}
```

期待される `output`:

```json
0
```

## 例 3

`input`:

```json
{
  "N": 20,
  "S": [
    "Aoki",
    "Takahashi",
    "Takahashi",
    "Aoki",
    "Aoki",
    "Aoki",
    "Aoki",
    "Takahashi",
    "Aoki",
    "Aoki",
    "Aoki",
    "Takahashi",
    "Takahashi",
    "Aoki",
    "Takahashi",
    "Aoki",
    "Aoki",
    "Aoki",
    "Aoki",
    "Takahashi"
  ]
}
```

期待される `output`:

```json
7
```

## 出典

この問題は ユニークビジョンプログラミングコンテスト2024 夏（AtCoder Beginner Contest 359）A「Count Takahashi」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc359/tasks/abc359_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
