# 奇数番目の文字

## 問題

英小文字からなる文字列 `s` があります。

先頭を 1 文字目として、1 文字目、3 文字目、5 文字目、... のように奇数文字目だけを順番に取り出した文字列を作ってください。

## 入力

`input` には英小文字からなる文字列 `s` が入っています。

## 制約

- `s` の各文字は英小文字です。
- `s` の長さは 1 以上 100000 以下です。

## 出力

`output` に、`s` の奇数文字目だけを順番に抜き出して作った文字列を代入してください。

## 例

### 例 1

`input`:

```json
"atcoder"
```

期待される `output`:

```json
"acdr"
```

この場合、1 文字目の `a`、3 文字目の `c`、5 文字目の `d`、7 文字目の `r` を取り出します。

### 例 2

`input`:

```json
"aaaa"
```

期待される `output`:

```json
"aa"
```

### 例 3

`input`:

```json
"z"
```

期待される `output`:

```json
"z"
```

### 例 4

`input`:

```json
"fukuokayamaguchi"
```

期待される `output`:

```json
"fkoaaauh"
```

## 出典

この問題は AtCoder Beginner Contest 072 B「OddString」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc072/tasks/abc072_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
