# 砂時計の残り

## 問題

`X` 秒を測れる砂時計があります。

はじめ、上の部分には `X` g の砂があります。砂は 1 秒ごとに 1 g ずつ下へ落ちます。ただし、上の部分に砂が残っていない場合、それ以上砂は落ちません。

`t` 秒後に、上の部分に残っている砂が何 g かを求めてください。

## 入力

`input` には、整数 `X` と `t` を持つオブジェクトが入っています。

- `1 <= X <= 1000000000`
- `1 <= t <= 1000000000`

## 出力

`output` に、`t` 秒後に上の部分に残っている砂の量を表す整数を代入してください。

## 例

`input`:

```json
{ "X": 100, "t": 17 }
```

期待される `output`:

```json
83
```

`input`:

```json
{ "X": 48, "t": 58 }
```

期待される `output`:

```json
0
```

`input`:

```json
{ "X": 1000000000, "t": 1000000000 }
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 072 A「Sandglass2」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc072/tasks/abc072_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
