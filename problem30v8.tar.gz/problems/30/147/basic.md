# Blackjack

## 問題

3 枚のカードの値 `A1`, `A2`, `A3` が与えられます。

3 つの値の合計が 22 以上なら `"bust"`、21 以下なら `"win"` を作ってください。

## 入力

`input` には、整数 `A1`, `A2`, `A3` を持つオブジェクトが入っています。

それぞれの整数は 1 以上 13 以下です。

## 出力

`output` に、合計が 22 以上なら `"bust"`、21 以下なら `"win"` の文字列を代入してください。

## 例 1

`input`:

```json
{
  "A1": 5,
  "A2": 7,
  "A3": 9
}
```

期待される `output`:

```json
"win"
```

`5 + 7 + 9 = 21` なので、`"win"` です。

## 例 2

`input`:

```json
{
  "A1": 13,
  "A2": 7,
  "A3": 2
}
```

期待される `output`:

```json
"bust"
```

`13 + 7 + 2 = 22` なので、`"bust"` です。

## 出典

この問題は AtCoder Beginner Contest 147 A「Blackjack」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc147/tasks/abc147_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
