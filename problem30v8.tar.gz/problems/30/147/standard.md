# 回文にする最小変更回数

## 問題

高八士君は回文が大好きで、回文でない文字列が許せません。

高八士君は文字列を 1 回ハグするごとに、文字列から 1 文字を選んで任意の文字に変えることができます。

文字列 `S` を回文にするために必要なハグの最小回数を求めてください。

回文とは、前から読んでも後ろから読んでも同じになる文字列のことです。

## 入力

`input` には、半角英小文字だけからなる文字列 `S` が入っています。

`S` の長さは 1 以上 100 以下です。

## 出力

`output` に、`S` を回文にするために必要なハグの最小回数を表す整数を代入してください。

## 例

`input`:

```json
"redcoder"
```

期待される `output`:

```json
1
```

たとえば、4 文字目を `o` に変えて `redooder` にすると回文になります。

## 出典

この問題は AtCoder Beginner Contest 147 B「Palindrome-philia」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc147/tasks/abc147_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
