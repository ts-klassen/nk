# 文字列を圧縮する

## 問題

英小文字だけからなる文字列 `s` があります。

`s` を、同じ文字が連続しているまとまりに左から順に分けます。各まとまりについて、その文字と連続している長さをつなげた文字列に変換し、変換した文字列を左から順につなげてください。

たとえば `aabbbaad` は、`aa`、`bbb`、`aa`、`d` に分けられます。それぞれ `a2`、`b3`、`a2`、`d1` に変換し、つなげると `a2b3a2d1` になります。

## 入力

`input` には、1 文字以上 1000 文字以下の英小文字だけからなる文字列 `s` が入っています。

## 出力

`output` に、`s` を上の方法で圧縮した文字列を代入してください。連続している長さは 10 進表記で書きます。

## 例

`input`:

```json
"aabbbaad"
```

期待される `output`:

```json
"a2b3a2d1"
```

`input`:

```json
"aabbbbbbbbbbbbxyza"
```

期待される `output`:

```json
"a2b12x1y1z1a1"
```

`input`:

```json
"edcba"
```

期待される `output`:

```json
"e1d1c1b1a1"
```

## 出典

この問題は AtCoder Beginner Contest 019 B「高橋くんと文字列圧縮」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc019/tasks/abc019_2?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
