# 共通する文字の種類数

## 問題

英小文字からなる長さ `N` の文字列 `S` があります。

`S` を 1 箇所で切って、左側の文字列 `X` と右側の文字列 `Y` に分けます。切る位置は、1 文字目と 2 文字目の間から、`N - 1` 文字目と `N` 文字目の間までのどこかです。

`X` と `Y` のどちらにも含まれている文字の種類数ができるだけ大きくなるように切るとき、その最大値を求めてください。

## 入力

`input` には、整数 `N` と文字列 `S` を持つオブジェクトが入っています。

- `2 <= N <= 100`
- `S` の長さは `N`
- `S` は英小文字だけからなる文字列

## 出力

`output` に、`X` と `Y` のどちらにも含まれている文字の種類数の最大値を表す整数を代入してください。

## 例 1

`input`:

```json
{
  "N": 6,
  "S": "aabbca"
}
```

期待される `output`:

```json
2
```

たとえば `S` を `aab` と `bca` に分けると、両方に含まれる文字は `a` と `b` の 2 種類です。

## 例 2

`input`:

```json
{
  "N": 10,
  "S": "aaaaaaaaaa"
}
```

期待される `output`:

```json
1
```

## 例 3

`input`:

```json
{
  "N": 45,
  "S": "tgxgdqkyjzhyputjjtllptdfxocrylqfqjynmfbfucbir"
}
```

期待される `output`:

```json
9
```

## 出典

この問題は AtCoder Beginner Contest 098 B「Cut and Count」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc098/tasks/abc098_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
