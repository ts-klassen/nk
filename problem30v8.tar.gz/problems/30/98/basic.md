# 最大の演算結果

## 問題

整数 `A` と `B` が与えられます。

`A + B`、`A - B`、`A * B` の 3 つの値のうち、最大の値を求めてください。

制約:

- `-1000 <= A, B <= 1000`
- `A` と `B` は整数

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

## 出力

`output` に、`A + B`、`A - B`、`A * B` の中で最大の値を代入してください。

## 例

### 例 1

`input`:

```json
{ "A": 3, "B": 1 }
```

期待される `output`:

```json
4
```

`3 + 1 = 4`、`3 - 1 = 2`、`3 * 1 = 3` なので、最大の値は `4` です。

### 例 2

`input`:

```json
{ "A": 4, "B": -2 }
```

期待される `output`:

```json
6
```

`4 - (-2) = 6` が最大の値です。

### 例 3

`input`:

```json
{ "A": 0, "B": 0 }
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 098 A「Add Sub Mul」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc098/tasks/abc098_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
