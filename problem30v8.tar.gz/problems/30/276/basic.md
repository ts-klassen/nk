# 最後の a の位置

## 問題

英小文字だけからなる文字列 `S` があります。

`S` に文字 `"a"` が含まれる場合は、最後に現れる `"a"` が先頭から何文字目かを求めてください。先頭の文字を 1 文字目として数えます。

`S` に `"a"` が含まれない場合は、`-1` を求めてください。

## 入力

`input` には、英小文字だけからなる長さ 1 以上 100 以下の文字列が入っています。

## 出力

`output` に、最後に現れる `"a"` の位置を整数で代入してください。

`"a"` が含まれない場合は、`output` に `-1` を代入してください。

## 例 1

`input`:

```json
"abcdaxayz"
```

期待される `output`:

```json
7
```

## 例 2

`input`:

```json
"bcbbbz"
```

期待される `output`:

```json
-1
```

## 例 3

`input`:

```json
"aaaaa"
```

期待される `output`:

```json
5
```

## 出典

この問題は AtCoder Beginner Contest 276 A「Rightmost」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc276/tasks/abc276_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
