# 異なる並べ替え文字列

## 問題

英小文字だけからなる長さ 3 の文字列 `S` があります。

`S` の各文字を並び替えて得られる文字列は、何種類あるか求めてください。

## 入力

`input` には、英小文字だけからなる長さ 3 の文字列が入っています。

## 出力

`output` に、`S` の各文字を並び替えて得られる文字列の種類数を数値で代入してください。

## 例

### 例 1

`input`:

```json
"aba"
```

期待される `output`:

```json
3
```

### 例 2

`input`:

```json
"ccc"
```

期待される `output`:

```json
1
```

### 例 3

`input`:

```json
"xyz"
```

期待される `output`:

```json
6
```

## 出典

この問題は UNICORNプログラミングコンテスト2021(AtCoder Beginner Contest 225) A「Distinct Strings」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc225/tasks/abc225_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
