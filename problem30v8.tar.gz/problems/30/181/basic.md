# 服の色

## 問題

高橋くんは今、白い服を着ています。

高橋くんは、白い服を着た次の日には黒い服を着て、黒い服を着た次の日には白い服を着ます。

`N` 日後には何色の服を着るか求めてください。

## 入力

`input` には整数 `N` が入っています。

制約:

- `N` は整数
- `1 <= N <= 30`

## 出力

`output` に、`N` 日後に白い服を着るなら `"White"` を、黒い服を着るなら `"Black"` を代入してください。

## 例 1

`input`:

```json
2
```

期待される `output`:

```json
"White"
```

高橋くんは 1 日後に黒い服を、2 日後に白い服を着ます。

## 例 2

`input`:

```json
5
```

期待される `output`:

```json
"Black"
```

## 出典

この問題は AtCoder Beginner Contest 181 A「Heavy Rotation」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc181/tasks/abc181_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
