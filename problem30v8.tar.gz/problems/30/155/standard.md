# Papers, Please

## 問題

ある入国者の書類には、`N` 個の整数 `A_1, A_2, ..., A_N` が書かれています。

入国を承認する条件は、書類に書かれている整数のうち、偶数であるものがすべて `3` または `5` で割り切れることです。

この条件を満たすなら `"APPROVED"`、満たさないなら `"DENIED"` を求めてください。

## 入力

`input` には、整数 `N` と配列 `A` を持つオブジェクトが入っています。

- `N` は配列 `A` の長さです。
- `A` には書類に書かれている整数が順番に入っています。
- `1 <= N <= 100`
- `1 <= A_i <= 1000`

## 出力

`output` に `"APPROVED"` または `"DENIED"` の文字列を代入してください。

## 例

`input`:

```json
{
  "N": 5,
  "A": [6, 7, 9, 10, 31]
}
```

期待される `output`:

```json
"APPROVED"
```

書類に書かれている偶数は `6` と `10` です。どちらも `3` または `5` で割り切れるため、条件を満たします。

`input`:

```json
{
  "N": 3,
  "A": [28, 27, 24]
}
```

期待される `output`:

```json
"DENIED"
```

`28` は偶数ですが、`3` でも `5` でも割り切れないため、条件を満たしません。

## 出典

この問題は AtCoder Beginner Contest 155 B「Papers, Please」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc155/tasks/abc155_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
