# 最多得票の文字列

## 問題

`N` 枚の投票用紙があります。
`i` 枚目の投票用紙には、文字列 `S_i` が書かれています。

すべての投票用紙を確認し、書かれた回数が最も多い文字列をすべて求めてください。
答えは辞書順で小さい順に並べます。

## 入力

`input` には、整数 `N` と文字列の配列 `S` を持つオブジェクトが入っています。

- `1 <= N <= 2 * 10^5`
- `S` の長さは `N` です。
- `S_i` は英小文字のみからなる文字列です。
- `S_i` の長さは `1` 以上 `10` 以下です。

## 出力

`output` には、書かれた回数が最も多い文字列を、辞書順で小さい順に並べた配列を代入してください。

## 例 1

`input`:

```json
{
  "N": 7,
  "S": ["beat", "vet", "beet", "bed", "vet", "bet", "beet"]
}
```

期待される `output`:

```json
["beet", "vet"]
```

`beet` と `vet` は 2 回ずつ、ほかの文字列は 1 回ずつ書かれています。

## 例 2

`input`:

```json
{
  "N": 8,
  "S": ["buffalo", "buffalo", "buffalo", "buffalo", "buffalo", "buffalo", "buffalo", "buffalo"]
}
```

期待される `output`:

```json
["buffalo"]
```

## 例 3

`input`:

```json
{
  "N": 7,
  "S": ["bass", "bass", "kick", "kick", "bass", "kick", "kick"]
}
```

期待される `output`:

```json
["kick"]
```

## 例 4

`input`:

```json
{
  "N": 4,
  "S": ["ushi", "tapu", "nichia", "kun"]
}
```

期待される `output`:

```json
["kun", "nichia", "tapu", "ushi"]
```

## 出典

この問題は AtCoder Beginner Contest 155 C「Poll」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc155/tasks/abc155_c?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
