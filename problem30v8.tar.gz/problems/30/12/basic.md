# スワップ

## 問題

整数 `A` と `B` が与えられます。

`A` と `B` の値を入れ替えたあと、入れ替え後の `A` と `B` を求めてください。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

`A` と `B` はどちらも `1` 以上 `100` 以下です。

## 出力

`output` には、入れ替え後の `A` と `B` をこの順に並べた配列を代入してください。

## 例

### 例1

`input`:

```json
{ "A": 1, "B": 2 }
```

期待される `output`:

```json
[2, 1]
```

### 例2

`input`:

```json
{ "A": 5, "B": 5 }
```

期待される `output`:

```json
[5, 5]
```

## 出典

この問題は AtCoder Beginner Contest 012 A「スワップ」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc012/tasks/abc012_1?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
