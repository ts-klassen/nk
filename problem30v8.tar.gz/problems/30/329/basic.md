# 文字を1文字ずつ並べる

## 問題

英大文字だけからなる文字列 `S` があります。

`S` の各文字を、先頭から順に 1 文字ずつ取り出して配列にしてください。

## 入力

`input` には、長さ 2 以上 100 以下の英大文字だけからなる文字列 `S` が入っています。

## 出力

`output` には、`S` の各文字を先頭から順に並べた配列を代入してください。

配列の各要素は、1 文字の文字列にしてください。

## 例

`input`:

```json
"ABC"
```

期待される `output`:

```json
["A", "B", "C"]
```

## 出典

この問題は Ｓｋｙ株式会社プログラミングコンテスト2023（AtCoder Beginner Contest 329） A「Spread」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc329/tasks/abc329_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
