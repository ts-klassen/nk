# 1 と 0 を交互に並べる

## 問題

正整数 `N` が与えられます。

`N` 個の `0` と `N + 1` 個の `1` を使って、`0` と `1` が交互に並んだ文字列を作ってください。

## 入力

`input` には整数 `N` が入っています。

- `N` は整数
- `1 <= N <= 100`

## 出力

`output` に、`N` 個の `0` と `N + 1` 個の `1` からなる、`0` と `1` が交互に並んだ文字列を代入してください。

## 例

`input`:

```json
4
```

期待される `output`:

```json
"101010101"
```

`input`:

```json
1
```

期待される `output`:

```json
"101"
```

`input`:

```json
10
```

期待される `output`:

```json
"101010101010101010101"
```

## 出典

この問題は トヨタ自動車プログラミングコンテスト2024#2（AtCoder Beginner Contest 341）A「Print 341」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc341/tasks/abc341_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
