# 最大の MEX

## 問題

長さ `N` の非負整数列 `A` が与えられます。

`A` から `K` 個の要素を選び、もとの順序を保ったまま並べた列を `B` とします。`B` の `MEX` としてありえる最大値を求めてください。

数列 `X` の `MEX(X)` は、次の条件を満たす唯一の非負整数 `m` です。

- `0 <= i < m` を満たす全ての整数 `i` が `X` に含まれる
- `m` が `X` に含まれない

## 制約

- `1 <= K <= N <= 3 * 10^5`
- `0 <= A_i <= 10^9`
- `input` に含まれる値はすべて整数

## 入力

`input` には、整数 `N`、整数 `K`、長さ `N` の整数配列 `A` を持つオブジェクトが入っています。

## 出力

`output` に、`A` から `K` 個を選んで作れる列 `B` の `MEX(B)` の最大値を表す整数を代入してください。

## 例

`input`:

```json
{
  "N": 7,
  "K": 3,
  "A": [2, 0, 2, 3, 2, 1, 9]
}
```

期待される `output`:

```json
3
```

例えば `A` の 2 番目、3 番目、6 番目の要素を選ぶと、`B` は `[0, 2, 1]` になり、`MEX(B)` は `3` です。これより大きい値は作れません。

## 出典

この問題は Toyota Programming Contest 2023 Spring Qual B（AtCoder Beginner Contest 290） C「Max MEX」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc290/tasks/abc290_c?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
