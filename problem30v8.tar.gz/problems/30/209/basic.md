# 整数の個数

## 問題

整数 `A` と `B` が与えられます。

`A` 以上 `B` 以下の整数がいくつあるかを求めてください。
`A` が `B` より大きい場合、そのような整数は存在しないため、個数は `0` です。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

`A` と `B` はどちらも `1` 以上 `100` 以下です。

```json
{
  "A": 2,
  "B": 4
}
```

## 出力

`output` に、`A` 以上 `B` 以下の整数の個数を表す整数を代入してください。

## 例 1

`input`:

```json
{
  "A": 2,
  "B": 4
}
```

期待される `output`:

```json
3
```

`2` 以上 `4` 以下の整数は `2`, `3`, `4` の `3` つです。

## 例 2

`input`:

```json
{
  "A": 10,
  "B": 100
}
```

期待される `output`:

```json
91
```

## 例 3

`input`:

```json
{
  "A": 3,
  "B": 2
}
```

期待される `output`:

```json
0
```

`3` 以上 `2` 以下の整数は存在しません。

## 出典

この問題は AtCoder Beginner Contest 209 A「Counting」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc209/tasks/abc209_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
