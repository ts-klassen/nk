# 狭義単調増加の判定

## 問題

正整数 `N` と、長さ `N` の正整数の配列 `A` が与えられます。

`A` が狭義単調増加であるとは、すべての隣り合う要素について、前の要素より次の要素のほうが大きいことをいいます。

`A` が狭義単調増加であるかを判定してください。

## 入力

`input` には、整数 `N` と配列 `A` を持つオブジェクトが入っています。

- `2 <= N <= 100`
- `A` の長さは `N`
- `1 <= A[i] <= 1000`

## 出力

`A` が狭義単調増加であるなら、`output` に `"Yes"` を代入してください。
そうでないなら、`output` に `"No"` を代入してください。

## 例

`input`:

```json
{
  "N": 3,
  "A": [1, 2, 5]
}
```

期待される `output`:

```json
"Yes"
```

`A[0] < A[1]` かつ `A[1] < A[2]` なので、狭義単調増加です。

## 出典

この問題は AtCoder Beginner Contest 395 A「Strictly Increasing?」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc395/tasks/abc395_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
