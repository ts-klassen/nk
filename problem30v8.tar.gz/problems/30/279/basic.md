# 下向きのとがりを数える

## 問題

`v` と `w` のみからなる文字列 `S` があります。

文字 `v` は下向きにとがっている部分を 1 箇所、文字 `w` は下向きにとがっている部分を 2 箇所持つと考えます。

`S` 全体に、下向きにとがっている部分が合計で何箇所あるかを求めてください。

## 入力

`input` には、文字 `v` と `w` のみからなる文字列が入っています。

文字列の長さは 1 以上 100 以下です。

## 出力

`output` に、下向きにとがっている部分の合計数を整数で代入してください。

## 例

`input`:

```json
"vvwvw"
```

期待される `output`:

```json
7
```

`input`:

```json
"v"
```

期待される `output`:

```json
1
```

`input`:

```json
"wwwvvvvvv"
```

期待される `output`:

```json
12
```

## 出典

この問題は トヨタシステムズプログラミングコンテスト2022(AtCoder Beginner Contest 279) A「wwwvvvvvv」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc279/tasks/abc279_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
