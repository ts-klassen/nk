# 部分文字列の判定

## 問題

英小文字からなる文字列 `S` と `T` が与えられます。

`T` が `S` の連続する部分文字列であるかを判定してください。

ここで、文字列 `X` の先頭または末尾から 1 文字を削除する操作を 0 回以上行って文字列 `Y` を作れるとき、`Y` は `X` の連続する部分文字列であるとします。

例えば、`tag` は `voltage` の連続する部分文字列ですが、`ace` は `atcoder` の連続する部分文字列ではありません。

## 入力

`input` には、英小文字からなる文字列 `S` と `T` を持つオブジェクトが入っています。

- `1 <= S.length <= 100`
- `1 <= T.length <= 100`

## 出力

`T` が `S` の連続する部分文字列なら、`output` に `"Yes"` を代入してください。
そうでなければ、`output` に `"No"` を代入してください。

## 例

### 例 1

`input`:

```json
{
  "S": "voltage",
  "T": "tag"
}
```

期待される `output`:

```json
"Yes"
```

### 例 2

`input`:

```json
{
  "S": "atcoder",
  "T": "ace"
}
```

期待される `output`:

```json
"No"
```

### 例 3

`input`:

```json
{
  "S": "gorilla",
  "T": "gorillagorillagorilla"
}
```

期待される `output`:

```json
"No"
```

### 例 4

`input`:

```json
{
  "S": "toyotasystems",
  "T": "toyotasystems"
}
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は トヨタシステムズプログラミングコンテスト2022(AtCoder Beginner Contest 279) B「LOOKUP」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc279/tasks/abc279_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
