# 積の偶奇判定

## 問題

2 つの正整数 `a` と `b` が与えられます。

`a` と `b` の積が偶数か奇数かを判定してください。

## 制約

- `1 <= a, b <= 10000`
- `a` と `b` は整数

## 入力

`input` には、整数 `a` と `b` を持つオブジェクトが入っています。

## 出力

`a` と `b` の積が奇数なら `output` に `"Odd"` を代入してください。
偶数なら `output` に `"Even"` を代入してください。

## 例

`input`:

```json
{
  "a": 3,
  "b": 4
}
```

期待される `output`:

```json
"Even"
```

`3 * 4 = 12` は偶数なので、答えは `"Even"` です。

## 出典

この問題は AtCoder Beginner Contest 086 A「Product」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc086/tasks/abc086_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
