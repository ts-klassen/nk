# 先頭に 0 を追加して回文にする

## 問題

整数 `N` が与えられます。

`N` を十進法で表した文字列の先頭に、0 個以上の `"0"` を追加して、回文にできるか判定してください。

回文とは、前から読んでも後ろから読んでも同じ文字列のことです。

## 入力

`input` には、0 以上 1000000000 以下の整数 `N` が入っています。

## 出力

回文にできるなら `output` に `"Yes"` を、できないなら `"No"` を代入してください。

## 例

`input`:

```json
1210
```

期待される `output`:

```json
"Yes"
```

`1210` の先頭に 1 個の `"0"` を追加すると `"01210"` となり、回文になります。

## 出典

この問題は AtCoder Beginner Contest 198 B「Palindrome with leading zeros」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc198/tasks/abc198_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
