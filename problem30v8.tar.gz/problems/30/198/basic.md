# お菓子の分け方

## 問題

`N` 個の区別できないお菓子を、A君とB君で分け合います。

A君もB君も、それぞれ 1 個以上の整数個のお菓子を受け取る必要があります。このような分け方が何通りあるかを求めてください。

## 入力

`input` には整数 `N` が入っています。

制約:

- `N` は整数
- `1 <= N <= 15`

## 出力

`output` に、条件を満たす分け方の数を整数で代入してください。

## 例

`input`:

```json
2
```

期待される `output`:

```json
1
```

A君が 1 個、B君が 1 個取る方法のみ存在します。

## 出典

この問題は AtCoder Beginner Contest 198 A「Div」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc198/tasks/abc198_a
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
