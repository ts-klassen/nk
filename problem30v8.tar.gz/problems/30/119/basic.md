# Still TBD

## 問題

日付を表す文字列 `S` が与えられます。

`S` は、2019 年の実在する日付を `yyyy/mm/dd` の形式で表した文字列です。たとえば、2019 年 4 月 30 日は `2019/04/30` と表されます。

`S` が表す日付が 2019 年 4 月 30 日またはそれ以前なら `"Heisei"`、そうでなければ `"TBD"` を答えてください。

## 入力

`input` には、2019 年の実在する日付を `yyyy/mm/dd` の形式で表す文字列が入っています。

## 出力

`output` に `"Heisei"` または `"TBD"` の文字列を代入してください。

`input` が表す日付が 2019 年 4 月 30 日またはそれ以前なら `"Heisei"`、そうでなければ `"TBD"` を代入してください。

## 例

`input`:

```json
"2019/04/30"
```

期待される `output`:

```json
"Heisei"
```

`input`:

```json
"2019/11/01"
```

期待される `output`:

```json
"TBD"
```

## 出典

この問題は AtCoder Beginner Contest 119 A「Still TBD」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc119/tasks/abc119_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
