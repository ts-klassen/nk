# 回文数の判定

## 問題

3 桁の正の整数 `N` が与えられます。

`N` が回文数であるかを判定してください。回文数とは、10 進法において数字を逆から並べても元の数と同じになる数のことです。

## 入力

`input` には、100 以上 999 以下の整数 `N` が入っています。

## 出力

`N` が回文数である場合は `output` に `"Yes"` を代入してください。そうでない場合は `output` に `"No"` を代入してください。

## 例

### 例 1

`input`:

```json
575
```

期待される `output`:

```json
"Yes"
```

`575` は逆から数字を並べても `575` となるため、回文数です。

### 例 2

`input`:

```json
123
```

期待される `output`:

```json
"No"
```

`123` は逆から数字を並べると `321` となるため、回文数ではありません。

### 例 3

`input`:

```json
812
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 070 A「Palindromic Number」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc070/tasks/abc070_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
