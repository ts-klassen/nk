# 2つのスイッチ

## 問題

Alice と Bob は、それぞれロボットを制御するスイッチを 1 つ持っています。

Alice は、ロボットが動き始めて `A` 秒後から `B` 秒後までスイッチを押しています。Bob は、ロボットが動き始めて `C` 秒後から `D` 秒後までスイッチを押しています。

Alice と Bob が二人ともスイッチを押していた秒数を求めてください。

## 入力

`input` には、整数 `A`、`B`、`C`、`D` を持つオブジェクトが入っています。

```json
{
  "A": 0,
  "B": 75,
  "C": 25,
  "D": 100
}
```

`A`、`B`、`C`、`D` は次の条件を満たします。

- `0 <= A < B <= 100`
- `0 <= C < D <= 100`

## 出力

`output` に、Alice と Bob が二人ともスイッチを押していた秒数を表す整数を代入してください。

## 例

`input`:

```json
{
  "A": 0,
  "B": 75,
  "C": 25,
  "D": 100
}
```

期待される `output`:

```json
50
```

`input`:

```json
{
  "A": 0,
  "B": 33,
  "C": 66,
  "D": 99
}
```

期待される `output`:

```json
0
```

`input`:

```json
{
  "A": 10,
  "B": 90,
  "C": 20,
  "D": 80
}
```

期待される `output`:

```json
60
```

## 出典

この問題は AtCoder Beginner Contest 070 B「Two Switches」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc070/tasks/abc070_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
