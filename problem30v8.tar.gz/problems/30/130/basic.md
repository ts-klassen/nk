# Rounding

## 問題

`X` と `A` は、どちらも `0` 以上 `9` 以下の整数です。

`X` が `A` 未満なら `0`、`A` 以上なら `10` を答えてください。

## 入力

`input` には、整数 `X` と `A` を持つオブジェクトが入っています。

```json
{
  "X": 3,
  "A": 5
}
```

## 出力

`output` に、条件に合う整数 `0` または `10` を代入してください。

## 例 1

`input`:

```json
{
  "X": 3,
  "A": 5
}
```

期待される `output`:

```json
0
```

`3` は `5` 未満なので、答えは `0` です。

## 例 2

`input`:

```json
{
  "X": 7,
  "A": 5
}
```

期待される `output`:

```json
10
```

`7` は `5` 以上なので、答えは `10` です。

## 例 3

`input`:

```json
{
  "X": 6,
  "A": 6
}
```

期待される `output`:

```json
10
```

`6` は `6` 以上なので、答えは `10` です。

## 出典

この問題は AtCoder Beginner Contest 130 A「Rounding」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc130/tasks/abc130_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
