# 行列式

## 問題

2 x 2 の行列 `[[a, b], [c, d]]` を考えます。

この行列の行列式は `a * d - b * c` で求められます。
`input` に含まれる 4 つの整数から、行列式を求めてください。

## 入力

`input` には、整数 `a`、`b`、`c`、`d` を持つオブジェクトが入っています。
これらは行列 `[[a, b], [c, d]]` の各要素を表します。

`a`、`b`、`c`、`d` はすべて整数で、`-100` 以上 `100` 以下です。

## 出力

`output` に、`a * d - b * c` の値を整数として代入してください。

## 例 1

`input`:

```json
{ "a": 1, "b": 2, "c": 3, "d": 4 }
```

期待される `output`:

```json
-2
```

`1 * 4 - 2 * 3 = -2` です。

## 例 2

`input`:

```json
{ "a": 0, "b": -1, "c": 1, "d": 0 }
```

期待される `output`:

```json
1
```

## 例 3

`input`:

```json
{ "a": 100, "b": 100, "c": 100, "d": 100 }
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 184 A「Determinant」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc184/tasks/abc184_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
