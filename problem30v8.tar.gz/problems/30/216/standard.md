# 同姓同名の確認

## 問題

`N` 人の人がいます。`i` 人目の人の姓は `S_i`、名は `T_i` です。

同姓同名であるような 2 人の組が存在するか判定してください。つまり、`1 <= i < j <= N` で、`S_i` と `S_j` が等しく、かつ `T_i` と `T_j` も等しい組があるかを調べます。

制約:

- `2 <= N <= 1000`
- `N` は整数
- `S_i` と `T_i` は英小文字のみからなる長さ `1` 以上 `10` 以下の文字列

## 入力

`input` には、整数 `N` と配列 `people` を持つオブジェクトが入っています。

`people` は長さ `N` の配列です。各要素は、姓を表す文字列 `S` と、名を表す文字列 `T` を持つオブジェクトです。

## 出力

同姓同名であるような 2 人の組が存在するなら、`output` に `"Yes"` を代入してください。

存在しないなら、`output` に `"No"` を代入してください。

## 例

`input`:

```json
{
  "N": 3,
  "people": [
    { "S": "tanaka", "T": "taro" },
    { "S": "sato", "T": "hanako" },
    { "S": "tanaka", "T": "taro" }
  ]
}
```

期待される `output`:

```json
"Yes"
```

`input`:

```json
{
  "N": 3,
  "people": [
    { "S": "saito", "T": "ichiro" },
    { "S": "saito", "T": "jiro" },
    { "S": "saito", "T": "saburo" }
  ]
}
```

期待される `output`:

```json
"No"
```

`input`:

```json
{
  "N": 4,
  "people": [
    { "S": "sypdgidop", "T": "bkseq" },
    { "S": "bajsqz", "T": "hh" },
    { "S": "ozjekw", "T": "mcybmtt" },
    { "S": "qfeysvw", "T": "dbo" }
  ]
}
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 216 B「Same Name」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc216/tasks/abc216_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
