# Signed Difficulty

## 問題

整数 `X` と、1 桁の整数 `Y` が与えられます。これは実数 `X.Y` を表します。

`Y` の値に応じて、次の文字列を作ってください。

- `0 <= Y <= 2` のとき、`X` の後ろに `-` を付ける
- `3 <= Y <= 6` のとき、`X` だけにする
- `7 <= Y <= 9` のとき、`X` の後ろに `+` を付ける

## 入力

`input` には、整数 `X` と `Y` を持つオブジェクトが入っています。

- `1 <= X <= 15`
- `0 <= Y <= 9`

## 出力

`output` に、上のルールで作った文字列を代入してください。

`X` と `+`、または `X` と `-` の間には空白を入れません。

## 例

`input`:

```json
{ "X": 15, "Y": 8 }
```

期待される `output`:

```json
"15+"
```

`input`:

```json
{ "X": 1, "Y": 0 }
```

期待される `output`:

```json
"1-"
```

`input`:

```json
{ "X": 12, "Y": 5 }
```

期待される `output`:

```json
"12"
```

## 出典

この問題は AtCoder Beginner Contest 216 A「Signed Difficulty」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc216/tasks/abc216_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
