# 採用面接の判定

## 問題

高橋君は、ある会社の採用面接で `N` 人の面接官から評価を受けました。

各面接官の評価は、長さ `N` の文字列 `S` で表されます。`S` の左から `i` 文字目は、`i` 番目の面接官の評価です。

- `o`: 良
- `-`: 可
- `x`: 不可

高橋君は、次の 2 つの条件を両方満たすときに合格します。

- `o` と評価した面接官が少なくとも 1 人いる
- `x` と評価した面接官がいない

高橋君が合格かどうかを判定してください。

## 入力

`input` には、次の値を持つオブジェクトが入っています。

- `N`: 面接官の人数を表す整数
- `S`: 各面接官の評価を左から順に並べた長さ `N` の文字列

制約は次の通りです。

- `1 <= N <= 100`
- `S` は `o`, `-`, `x` のみからなる長さ `N` の文字列

## 出力

`output` に、合格なら `"Yes"`、そうでなければ `"No"` を代入してください。

## 例

### 例 1

`input`:

```json
{ "N": 4, "S": "oo--" }
```

期待される `output`:

```json
"Yes"
```

`o` と評価した面接官がいて、`x` と評価した面接官はいないため合格です。

### 例 2

`input`:

```json
{ "N": 3, "S": "---" }
```

期待される `output`:

```json
"No"
```

`o` と評価した面接官が 1 人もいないため不合格です。

### 例 3

`input`:

```json
{ "N": 1, "S": "o" }
```

期待される `output`:

```json
"Yes"
```

### 例 4

`input`:

```json
{
  "N": 100,
  "S": "ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooox"
}
```

期待される `output`:

```json
"No"
```

`x` と評価した面接官がいるため不合格です。

## 出典

この問題は トヨタ自動車プログラミングコンテスト2023#1(AtCoder Beginner Contest 298) A「Job Interview」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc298/tasks/abc298_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
