# パイプで囲まれた部分を消す

## 問題

英小文字と `|` だけからなる文字列 `S` が与えられます。
`S` には `|` がちょうど 2 個含まれています。

2 個の `|` と、その間にある文字をすべて取り除いた文字列を作ってください。

## 入力

`input` には、文字列 `S` が入っています。

`S` は次の条件を満たします。

- `S` の長さは 2 以上 100 以下
- `S` は英小文字と `|` だけからなる
- `S` には `|` がちょうど 2 個含まれる

## 出力

`output` に、2 個の `|` とその間の文字を取り除いた文字列を代入してください。

## 例

`input`:

```json
"atcoder|beginner|contest"
```

期待される `output`:

```json
"atcodercontest"
```

2 個の `|` に挟まれた `beginner` と、2 個の `|` が取り除かれます。

`input`:

```json
"|spoiler|"
```

期待される `output`:

```json
""
```

すべての文字が取り除かれることもあります。

`input`:

```json
"||xyz"
```

期待される `output`:

```json
"xyz"
```

## 出典

この問題は トヨタ自動車プログラミングコンテスト2024#3（AtCoder Beginner Contest 344） A「Spoiler」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc344/tasks/abc344_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
