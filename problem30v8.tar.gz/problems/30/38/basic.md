# お茶

## 問題

高橋くんは、ドリンクバーにある飲み物のローマ字表記を見ています。

この問題では、ローマ字表記が文字 `T` で終わる飲み物だけを「お茶」とみなします。
文字列 `S` が与えられるので、その飲み物がお茶かどうかを判定してください。

## 制約

- `S` の長さは 1 以上 50 以下です。
- `S` は英大文字だけでできています。

## 入力

`input` には、飲み物のローマ字表記を表す文字列 `S` がそのまま入っています。

## 出力

`S` が `T` で終わるなら `output` に `"YES"` を、そうでなければ `"NO"` を代入してください。

## 例

### 例 1

`input`:

```json
"ICEDT"
```

期待される `output`:

```json
"YES"
```

### 例 2

`input`:

```json
"MUGICHA"
```

期待される `output`:

```json
"NO"
```

### 例 3

`input`:

```json
"OOLONGT"
```

期待される `output`:

```json
"YES"
```

### 例 4

`input`:

```json
"T"
```

期待される `output`:

```json
"YES"
```

### 例 5

`input`:

```json
"TEA"
```

期待される `output`:

```json
"NO"
```

## 出典

この問題は AtCoder Beginner Contest 038 A「お茶」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc038/tasks/abc038_a?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
