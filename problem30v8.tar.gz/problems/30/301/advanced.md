# AtCoder Cards

## 問題

カードには、英小文字 1 文字または `@` が書かれています。
最初に同じ枚数のカードを 2 列に並べ、その 2 列を表す文字列をそれぞれ `S` と `T` とします。

あなたは、各列の中でカードを自由に並び替えられます。
また、`@` のカードはそれぞれ `a`, `t`, `c`, `o`, `d`, `e`, `r` のいずれかの文字のカードとして扱えます。

この操作によって、2 列を完全に同じ並びにできるか判定してください。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

`S` と `T` は英小文字と `@` からなる同じ長さの文字列で、長さは 1 以上 200000 以下です。

## 出力

2 列を同じ並びにできるなら、`output` に `"Yes"` を代入してください。
できないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{ "S": "ch@ku@ai", "T": "choku@@i" }
```

期待される `output`:

```json
"Yes"
```

`@` をうまく置き換えることで、どちらの列も `chokudai` にできます。

## 例 2

`input`:

```json
{ "S": "ch@kud@i", "T": "akidu@ho" }
```

期待される `output`:

```json
"Yes"
```

並び替えと `@` の置き換えによって、どちらの列も `chokudai` にできます。

## 例 3

`input`:

```json
{ "S": "aoki", "T": "@ok@" }
```

期待される `output`:

```json
"No"
```

## 例 4

`input`:

```json
{ "S": "aa", "T": "bb" }
```

期待される `output`:

```json
"No"
```

## 出典

この問題はパナソニックグループプログラミングコンテスト2023（AtCoder Beginner Contest 301） C「AtCoder Cards」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc301/tasks/abc301_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
