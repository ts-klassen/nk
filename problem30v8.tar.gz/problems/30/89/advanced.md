# 名前の頭文字で選ぶ

## 問題

`N` 人の人がいて、`i` 番目の人の名前は `S_i` です。

この中から、次の条件をすべて満たすように 3 人を選びます。

- 選んだ人の名前がすべて `M`, `A`, `R`, `C`, `H` のどれかから始まっている
- 選んだ 3 人の名前の先頭文字がすべて異なる

条件を満たす 3 人の選び方が何通りあるかを求めてください。選ぶ順番は区別しません。

答えは 32 bit 整数型に収まらない場合があります。

## 入力

`input` には、整数 `N` と文字列の配列 `S` を持つオブジェクトが入っています。

- `1 <= N <= 100000`
- `S` の長さは `N` です
- `S_i` は英大文字からなる文字列です
- `1 <= S_i.length <= 10`
- すべての名前は互いに異なります

## 出力

`output` に、条件を満たす 3 人の選び方の数を数値で代入してください。

## 例 1

`input`:

```json
{
  "N": 5,
  "S": ["MASHIKE", "RUMOI", "OBIRA", "HABORO", "HOROKANAI"]
}
```

期待される `output`:

```json
2
```

`MASHIKE`, `RUMOI`, `HABORO` を選ぶ方法と、`MASHIKE`, `RUMOI`, `HOROKANAI` を選ぶ方法があります。

## 例 2

`input`:

```json
{
  "N": 4,
  "S": ["ZZ", "ZZZ", "Z", "ZZZZZZZZZZ"]
}
```

期待される `output`:

```json
0
```

条件を満たす 3 人を選べない場合もあります。

## 例 3

`input`:

```json
{
  "N": 5,
  "S": ["CHOKUDAI", "RNG", "MAKOTO", "AOKI", "RINGO"]
}
```

期待される `output`:

```json
7
```

## 出典

この問題は AtCoder Beginner Contest 089 C「March」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc089/tasks/abc089_c?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
