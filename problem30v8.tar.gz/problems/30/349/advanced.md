# 空港コード

## 問題

英小文字だけからなる文字列 `S` と、英大文字だけからなる長さ `3` の文字列 `T` が与えられます。

`T` が `S` の **空港コード** であるとは、次のどちらかを満たすことです。

- `S` から順序を保って `3` 文字を選び、それを英大文字にしたものが `T` になる。
- `S` から順序を保って `2` 文字を選び、それを英大文字にした文字列の末尾に `"X"` を付けたものが `T` になる。

選ぶ文字は隣り合っている必要はありません。`T` が `S` の空港コードであるか判定してください。

制約:

- `S` は英小文字からなる長さ `3` 以上 `100000` 以下の文字列です。
- `T` は英大文字からなる長さ `3` の文字列です。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

```json
{
  "S": "narita",
  "T": "NRT"
}
```

## 出力

`output` に、`T` が `S` の空港コードなら `"Yes"`、そうでなければ `"No"` の文字列を代入してください。

## 例

`input`:

```json
{
  "S": "narita",
  "T": "NRT"
}
```

期待される `output`:

```json
"Yes"
```

`input`:

```json
{
  "S": "losangeles",
  "T": "LAX"
}
```

期待される `output`:

```json
"Yes"
```

`input`:

```json
{
  "S": "snuke",
  "T": "RNG"
}
```

期待される `output`:

```json
"No"
```

## 出典

この問題は AtCoder Beginner Contest 349 C「Airport Code」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc349/tasks/abc349_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
