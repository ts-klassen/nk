# 良い文字列

## 問題

英小文字からなる文字列 `S` について、次の条件を満たすとき `S` を「良い文字列」と呼びます。

- すべての 1 以上の整数 `i` について、`S` にちょうど `i` 回現れる文字の種類数が、0 種類または 2 種類である

与えられた文字列 `S` が良い文字列か判定してください。

## 入力

`input` には、英小文字からなる長さ 1 以上 100 以下の文字列が入っています。この文字列を `S` とします。

## 出力

`output` に、`S` が良い文字列なら `"Yes"`、そうでないなら `"No"` を代入してください。

## 例 1

`input`:

```json
"commencement"
```

期待される `output`:

```json
"Yes"
```

`commencement` では、1 回現れる文字が `o` と `t`、2 回現れる文字が `c` と `n`、3 回現れる文字が `e` と `m` のそれぞれ 2 種類です。4 回以上現れる文字は 0 種類なので、良い文字列です。

## 例 2

`input`:

```json
"banana"
```

期待される `output`:

```json
"No"
```

`banana` では、1 回現れる文字が `b` の 1 種類だけなので、良い文字列ではありません。

## 例 3

`input`:

```json
"ab"
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 349 B「Commencement」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc349/tasks/abc349_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
