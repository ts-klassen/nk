# プロコンの合計得点

## 問題

高橋君は、グラフ上に適切にプロットする力を問うコンテストに参加しています。

高橋君は 3 つの課題に取り組みました。それぞれの課題には配点があり、1 以上 10 以下の整数で評価が付きます。

評価が `rating` のとき、その課題では配点の `rating` 割の得点が与えられます。たとえば評価が 7 なら、配点の 70% の得点です。

3 つの課題の配点と評価から、高橋君が合計で何点獲得したかを求めてください。

## 入力

`input` には、長さ 3 の配列 `tasks` を持つオブジェクトが入っています。

`tasks` の各要素は、次の 2 つの整数を持つオブジェクトです。

- `points`: 課題の配点
- `rating`: 課題の評価

それぞれの `points` は 10 以上 990 以下の 10 の倍数です。それぞれの `rating` は 1 以上 10 以下です。

## 出力

`output` に、3 つの課題の合計得点を整数で代入してください。

## 例1

`input`:

```json
{
  "tasks": [
    { "points": 50, "rating": 7 },
    { "points": 40, "rating": 8 },
    { "points": 30, "rating": 9 }
  ]
}
```

期待される `output`:

```json
94
```

## 例2

`input`:

```json
{
  "tasks": [
    { "points": 990, "rating": 10 },
    { "points": 990, "rating": 10 },
    { "points": 990, "rating": 10 }
  ]
}
```

期待される `output`:

```json
2970
```

## 出典

この問題は AtCoder Beginner Contest 017 A「プロコン」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc017/tasks/abc017_1?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
