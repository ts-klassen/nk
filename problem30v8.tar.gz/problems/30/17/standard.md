# choku語

## 問題

半角小文字アルファベットからなる文字列 `X` が与えられます。

choku 語とは、空文字列から始めて、末尾に `"ch"`、`"o"`、`"k"`、`"u"` のいずれかを何回か追加して作ることができる文字列です。

`X` が choku 語かどうかを判定してください。

## 入力

`input` には、半角小文字アルファベットからなる文字列 `X` が入っています。

制約:

- `1 <= X.length <= 50`

## 出力

`X` が choku 語なら `output` に `"YES"` を、そうでないなら `"NO"` を代入してください。

## 例

`input`:

```json
"chokuou"
```

期待される `output`:

```json
"YES"
```

`input`:

```json
"kuccho"
```

期待される `output`:

```json
"NO"
```

`input`:

```json
"atcoder"
```

期待される `output`:

```json
"NO"
```

## 出典

この問題は AtCoder Beginner Contest 017 B「choku語」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc017/tasks/abc017_2?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
