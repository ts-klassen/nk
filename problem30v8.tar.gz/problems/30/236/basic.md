# 文字の入れ替え

## 問題

英小文字からなる文字列 `S` があります。

`S` の先頭から `a` 文字目と `b` 文字目を入れ替えてできる文字列を求めてください。
文字の位置は 1 から数えます。

## 入力

`input` には、次のプロパティを持つオブジェクトが入っています。

- `S`: 英小文字からなる文字列
- `a`: 入れ替える 1 つ目の文字の位置を表す整数
- `b`: 入れ替える 2 つ目の文字の位置を表す整数

条件は次の通りです。

- `S` の長さを `|S|` とすると、`2 <= |S| <= 10`
- `1 <= a < b <= |S|`

## 出力

`output` に、`S` の `a` 文字目と `b` 文字目を入れ替えてできる文字列を代入してください。

## 例

`input`:

```json
{ "S": "chokudai", "a": 3, "b": 5 }
```

期待される `output`:

```json
"chukodai"
```

`input`:

```json
{ "S": "aa", "a": 1, "b": 2 }
```

期待される `output`:

```json
"aa"
```

`input`:

```json
{ "S": "aaaabbbb", "a": 1, "b": 8 }
```

期待される `output`:

```json
"baaabbba"
```

## 出典

この問題は AtCoder Beginner Contest 236 A「chukodai」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc236/tasks/abc236_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
