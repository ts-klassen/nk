# 整数の合計

## 問題

`N` 個の整数 `A_1, A_2, ..., A_N` が与えられます。

これら `N` 個の整数をすべて合計した値を求めてください。

制約:

- `1 <= N <= 100`
- `1 <= A_i <= 100`
- `input` に入っている値はすべて整数です。

## 入力

`input` には、整数 `N` と整数の配列 `A` を持つオブジェクトが入っています。

`A` の長さは `N` です。

## 出力

`output` に、配列 `A` のすべての整数を合計した数値を代入してください。

## 例

`input`:

```json
{
  "N": 3,
  "A": [2, 7, 2]
}
```

期待される `output`:

```json
11
```

`input`:

```json
{
  "N": 1,
  "A": [3]
}
```

期待される `output`:

```json
3
```

## 出典

この問題は AtCoder Beginner Contest 272 A「Integer Sum」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc272/tasks/abc272_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
