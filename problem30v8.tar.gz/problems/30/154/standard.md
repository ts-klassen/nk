# すべて x に置き換える

## 問題

英小文字だけからなる文字列 `S` があります。
`S` のすべての文字を、同じ個数の `x` に置き換えた文字列を作ってください。

## 入力

`input` には、英小文字だけからなる文字列 `S` が入っています。

制約:

- `S` の長さは 1 以上 100 以下です。

## 出力

`output` に、`S` のすべての文字を `x` に置き換えた文字列を代入してください。

## 例

`input`:

```json
"sardine"
```

期待される `output`:

```json
"xxxxxxx"
```

`input`:

```json
"xxxx"
```

期待される `output`:

```json
"xxxx"
```

`input`:

```json
"gone"
```

期待される `output`:

```json
"xxxx"
```

## 出典

この問題は AtCoder Beginner Contest 154 B「I miss you...」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc154/tasks/abc154_b?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
