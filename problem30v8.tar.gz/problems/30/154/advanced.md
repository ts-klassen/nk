# すべて異なるか判定

## 問題

整数列 `A` が与えられます。
`A` のどの 2 つの要素も互いに異なるなら `"YES"` を、同じ値の要素が 1 組でもあるなら `"NO"` を求めてください。

## 入力

`input` には、整数 `N` と整数列 `A` を持つオブジェクトが入っています。
`A` は長さ `N` の配列です。

制約:

- `2 <= N <= 200000`
- `1 <= A[i] <= 1000000000`
- 入力される値はすべて整数

## 出力

`output` に `"YES"` または `"NO"` の文字列を代入してください。

## 例 1

`input`:

```json
{
  "N": 5,
  "A": [2, 6, 1, 4, 5]
}
```

期待される `output`:

```json
"YES"
```

どの 2 つの要素も互いに異なります。

## 例 2

`input`:

```json
{
  "N": 6,
  "A": [4, 1, 3, 1, 6, 2]
}
```

期待される `output`:

```json
"NO"
```

2 番目の要素と 4 番目の要素が同じです。

## 例 3

`input`:

```json
{
  "N": 2,
  "A": [10000000, 10000000]
}
```

期待される `output`:

```json
"NO"
```

## 出典

この問題は AtCoder Beginner Contest 154 C「Distinct or Not」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc154/tasks/abc154_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
