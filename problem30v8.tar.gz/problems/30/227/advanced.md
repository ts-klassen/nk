# ABC conjecture

## 問題

正の整数 `N` が与えられます。

`A <= B <= C` かつ `A * B * C <= N` を満たす正の整数の組 `(A, B, C)` がいくつあるかを求めてください。

制約の範囲では、答えは `2^63` 未満であることが保証されています。

## 入力

`input` には整数 `N` が入っています。

制約:

- `1 <= N <= 10^11`
- `N` は整数

## 出力

`output` に、条件を満たす正の整数の組 `(A, B, C)` の個数を表す整数を代入してください。

## 例

`input`:

```json
4
```

期待される `output`:

```json
5
```

条件を満たす組は `(1, 1, 1)`, `(1, 1, 2)`, `(1, 1, 3)`, `(1, 1, 4)`, `(1, 2, 2)` の 5 つです。

`input`:

```json
100
```

期待される `output`:

```json
323
```

`input`:

```json
100000000000
```

期待される `output`:

```json
5745290566750
```

## 出典

この問題は AtCoder Beginner Contest 227 C「ABC conjecture」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc227/tasks/abc227_c?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
