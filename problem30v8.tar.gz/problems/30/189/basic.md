# スロットの当たり判定

## 問題

スロットを回した結果が、3 文字の英大文字からなる文字列で表されます。

3 文字がすべて同じ文字なら当たりです。当たりかどうかを判定してください。

## 入力

`input` には、3 文字の英大文字からなる文字列が入っています。

## 出力

当たりなら `output` に `"Won"` を代入してください。

当たりでないなら `output` に `"Lost"` を代入してください。

## 例

`input`:

```json
"SSS"
```

期待される `output`:

```json
"Won"
```

## 出典

この問題は AtCoder Beginner Contest 189 A「Slot」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc189/tasks/abc189_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
