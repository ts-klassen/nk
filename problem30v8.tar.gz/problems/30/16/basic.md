# 12月6日

## 問題

日付の月と日が与えられます。

月を日で割り切れるかを判定してください。

## 入力

`input` には、月を表す整数 `M` と日を表す整数 `D` を持つオブジェクトが入っています。

## 出力

`M` が `D` で割り切れるなら、`output` に文字列 `"YES"` を代入してください。
割り切れないなら、`output` に文字列 `"NO"` を代入してください。

## 例1

`input`:

```json
{ "M": 1, "D": 1 }
```

期待される `output`:

```json
"YES"
```

## 例2

`input`:

```json
{ "M": 2, "D": 29 }
```

期待される `output`:

```json
"NO"
```

## 例3

`input`:

```json
{ "M": 12, "D": 6 }
```

期待される `output`:

```json
"YES"
```

## 出典

この問題は AtCoder Beginner Contest 016 A「12月6日」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc016/tasks/abc016_1?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
