# 交互に並べた文字列

## 問題

英小文字のみからなる同じ長さの文字列 `S` と `T` があります。

`S` の 1 文字目、`T` の 1 文字目、`S` の 2 文字目、`T` の 2 文字目、...、`S` の `N` 文字目、`T` の `N` 文字目の順に文字を並べた、新しい文字列を作ってください。

## 入力

`input` には、整数 `N` と文字列 `S`、`T` を持つオブジェクトが入っています。

- `1 <= N <= 100`
- `S` と `T` の長さはどちらも `N`
- `S` と `T` は英小文字のみからなる文字列

## 出力

`output` に、`S` と `T` の各文字を先頭から順に交互に並べた文字列を代入してください。

## 例 1

`input`:

```json
{ "N": 2, "S": "ip", "T": "cc" }
```

期待される `output`:

```json
"icpc"
```

## 例 2

`input`:

```json
{ "N": 8, "S": "hmhmnknk", "T": "uuuuuuuu" }
```

期待される `output`:

```json
"humuhumunukunuku"
```

## 例 3

`input`:

```json
{ "N": 5, "S": "aaaaa", "T": "aaaaa" }
```

期待される `output`:

```json
"aaaaaaaaaa"
```

## 出典

この問題は AtCoder Beginner Contest 148 B「Strings with the Same Length」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc148/tasks/abc148_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
