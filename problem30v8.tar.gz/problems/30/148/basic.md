# Round One

## 問題

3 択クイズの答えは、`1`、`2`、`3` のいずれかです。

高橋君は、`A` と `B` がどちらも誤答であることを知っています。

`1`、`2`、`3` のうち、`A` でも `B` でもない数を求めてください。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

```json
{
  "A": 3,
  "B": 1
}
```

`A` と `B` は `1`、`2`、`3` のいずれかで、互いに異なります。

## 出力

`output` に、正しい答えである整数を代入してください。

## 例 1

`input`:

```json
{
  "A": 3,
  "B": 1
}
```

期待される `output`:

```json
2
```

## 例 2

`input`:

```json
{
  "A": 1,
  "B": 2
}
```

期待される `output`:

```json
3
```

## 出典

この問題は AtCoder Beginner Contest 148 A「Round One」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc148/tasks/abc148_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
