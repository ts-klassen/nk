# Happy Birthday!

## 問題

円形のケーキが 16 等分されています。

E869120 君はそのうち `A` 切れ、square1001 君は `B` 切れを食べたいと思っています。
ただし、同じ人が隣り合う 2 切れのケーキを両方取ってはいけません。

2 人ともこの条件を守って、食べたい数のケーキを取ることができるか判定してください。

## 入力

`input` には、整数 `A` と `B` を持つオブジェクトが入っています。

`A` と `B` はそれぞれ 1 以上 16 以下で、`A + B` は 16 以下です。

## 出力

2 人とも食べたい数のケーキを取ることができるなら、`output` に `"Yay!"` を代入してください。
そうでなければ、`output` に `":("` を代入してください。

## 例 1

`input`:

```json
{ "A": 5, "B": 4 }
```

期待される `output`:

```json
"Yay!"
```

## 例 2

`input`:

```json
{ "A": 8, "B": 8 }
```

期待される `output`:

```json
"Yay!"
```

## 例 3

`input`:

```json
{ "A": 11, "B": 4 }
```

期待される `output`:

```json
":("
```

## 出典

この問題は AtCoder Beginner Contest 100 A「Happy Birthday!」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc100/tasks/abc100_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
