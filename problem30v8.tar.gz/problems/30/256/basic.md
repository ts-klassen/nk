# 2 の N 乗

## 問題

整数 `N` が与えられます。

`2` を `N` 回かけた値を求めてください。`N` が `0` のとき、答えは `1` です。

## 入力

`input` には整数 `N` が入っています。

`N` は次の条件を満たします。

- `0 <= N <= 30`

## 出力

`output` に `2` の `N` 乗を表す整数を代入してください。

## 例

`input`:

```json
3
```

期待される `output`:

```json
8
```

`2` の `3` 乗は `8` です。

## 出典

この問題は 東京海上日動プログラミングコンテスト2022（AtCoder Beginner Contest 256） A「2^N」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc256/tasks/abc256_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
