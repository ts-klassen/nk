# 回文になる連結

## 問題

英小文字だけからなる `N` 個の文字列 `S` が与えられます。

配列 `S` の異なる 2 つの位置 `i` と `j` を選び、`S[i]` と `S[j]` をこの順に連結します。この連結した文字列が回文になるような選び方が存在するか判定してください。

回文とは、前から読んでも後ろから読んでも同じ文字列のことです。

## 入力

`input` には、整数 `N` と文字列の配列 `S` を持つオブジェクトが入っています。

- `2 <= N <= 100`
- `S` の長さは `N`
- 各文字列の長さは `1` 以上 `50` 以下
- 各文字列は英小文字だけからなる
- `S` に含まれる文字列はすべて異なる

## 出力

条件を満たす異なる 2 つの位置 `i`, `j` が存在するなら、`output` に `"Yes"` を代入してください。
存在しないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{
  "N": 5,
  "S": ["ab", "ccef", "da", "a", "fe"]
}
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
{
  "N": 3,
  "S": ["a", "b", "aba"]
}
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
{
  "N": 2,
  "S": [
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ]
}
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は 東京海上日動プログラミングコンテスト2023（AtCoder Beginner Contest 307） B「racecar」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc307/tasks/abc307_b?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
