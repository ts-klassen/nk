# 九九の積判定

## 問題

高橋君は九九を覚えたので、1 以上 9 以下の 2 つの整数の積を計算できます。

整数 `N` が与えられます。`N` を 1 以上 9 以下の 2 つの整数 `a` と `b` を使って `a * b` と表せるか判定してください。

## 入力

`input` には、1 以上 100 以下の整数 `N` が数値として入っています。

## 出力

`N` を 1 以上 9 以下の 2 つの整数の積として表せるなら、`output` に `"Yes"` を代入してください。表せないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
10
```

期待される `output`:

```json
"Yes"
```

`10` は、例えば `2 * 5` と表せます。

## 例 2

`input`:

```json
50
```

期待される `output`:

```json
"No"
```

`50` を 1 以上 9 以下の 2 つの整数の積として表すことはできません。

## 例 3

`input`:

```json
81
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 144 B「81」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc144/tasks/abc144_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
