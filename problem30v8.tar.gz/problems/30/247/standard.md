# 一意なあだ名

## 問題

`N` 人の人がいます。人 `i` の姓は `s_i`、名は `t_i` です。

全員にあだ名を 1 つずつ付けます。人 `i` のあだ名は、次の 2 つの条件を満たす必要があります。

- 人 `i` の姓または名と一致する。
- 自分以外の誰かの姓や名とは一致しない。

全員に条件を満たすあだ名を付けられるか判定してください。

## 入力

`input` には、整数 `N` と配列 `people` を持つオブジェクトが入っています。

`people` の長さは `N` です。`people[i]` は `i + 1` 人目の情報を表すオブジェクトで、姓を表す文字列 `s` と名を表す文字列 `t` を持ちます。

制約:

- `2 <= N <= 100`
- `N` は整数
- `s` と `t` は英小文字からなる 1 文字以上 10 文字以下の文字列

## 出力

全員に条件を満たすあだ名を付けられるなら、`output` に `"Yes"` を代入してください。

そうでないなら、`output` に `"No"` を代入してください。

## 例 1

`input`:

```json
{
  "N": 3,
  "people": [
    { "s": "tanaka", "t": "taro" },
    { "s": "tanaka", "t": "jiro" },
    { "s": "suzuki", "t": "hanako" }
  ]
}
```

期待される `output`:

```json
"Yes"
```

## 例 2

`input`:

```json
{
  "N": 3,
  "people": [
    { "s": "aaa", "t": "bbb" },
    { "s": "xxx", "t": "aaa" },
    { "s": "bbb", "t": "yyy" }
  ]
}
```

期待される `output`:

```json
"No"
```

## 例 3

`input`:

```json
{
  "N": 2,
  "people": [
    { "s": "tanaka", "t": "taro" },
    { "s": "tanaka", "t": "taro" }
  ]
}
```

期待される `output`:

```json
"No"
```

## 例 4

`input`:

```json
{
  "N": 3,
  "people": [
    { "s": "takahashi", "t": "chokudai" },
    { "s": "aoki", "t": "kensho" },
    { "s": "snu", "t": "ke" }
  ]
}
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 247 B「Unique Nicknames」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc247/tasks/abc247_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
