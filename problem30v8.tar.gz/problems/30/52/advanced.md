# 階乗の約数の個数

## 問題

整数 `N` が与えられます。

`N!` は、`1` から `N` までのすべての整数を掛け合わせた数です。
`N!` の正の約数の個数を求め、その値を `1000000007` で割った余りを答えてください。

## 入力

`input` には整数 `N` が入っています。

制約:

- `1 <= N <= 1000`

## 出力

`output` に、`N!` の正の約数の個数を `1000000007` で割った余りを表す整数を代入してください。

## 例 1

`input`:

```json
3
```

期待される `output`:

```json
4
```

`3! = 6` です。`6` の正の約数は `1`, `2`, `3`, `6` の `4` 個です。

## 例 2

`input`:

```json
6
```

期待される `output`:

```json
30
```

## 例 3

`input`:

```json
1000
```

期待される `output`:

```json
972926972
```

## 出典

この問題は AtCoder Beginner Contest 052 C「Factors of Factorial」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc052/tasks/arc067_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
