# Increment Decrement

## 問題

整数 `x` があります。最初、`x` は `0` です。

長さ `N` の文字列 `S` を左から順に読み、各文字に応じて `N` 回の操作を行います。

- 文字が `"I"` のとき、`x` を `1` 増やします。
- 文字が `"D"` のとき、`x` を `1` 減らします。

操作の途中で `x` がとる値の最大値を求めてください。ここで、1 回目の操作を行う前の `x = 0` の状態と、最後の操作を行った後の状態も含めます。

## 入力

`input` には、整数 `N` と文字列 `S` を持つオブジェクトが入っています。

`S` の長さは `N` で、`S` に含まれる文字は `"I"` と `"D"` だけです。

制約:

- `1 <= N <= 100`
- `S.length === N`

## 出力

`output` に、操作の途中で `x` がとる値の最大値を整数として代入してください。

## 例 1

`input`:

```json
{ "N": 5, "S": "IIDID" }
```

期待される `output`:

```json
2
```

## 例 2

`input`:

```json
{ "N": 7, "S": "DDIDDII" }
```

期待される `output`:

```json
0
```

## 出典

この問題は AtCoder Beginner Contest 052 B「Increment Decrement」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc052/tasks/abc052_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
