# 2 番目に高い山

## 問題

AtCoder 国には `N` 個の山があります。`i` 番目の山の名前は `S_i`、高さは `T_i` です。

`N` 個の山の名前はすべて異なり、高さもすべて異なります。2 番目に高い山の名前を求めてください。

## 入力

`input` には、整数 `N` と配列 `mountains` を持つオブジェクトが入っています。

`mountains` の長さは `N` です。各要素は、山の名前 `S` と高さ `T` を持つオブジェクトです。

満たす条件は次の通りです。

- `2 <= N <= 1000`
- `S` の長さは `1` 以上 `15` 以下
- `S` は英小文字、英大文字、数字のみからなる
- `1 <= T <= 100000`
- 山の名前はすべて異なる
- 山の高さはすべて異なる
- `N` と `T` は整数

## 出力

`output` に、2 番目に高い山の名前を表す文字列を代入してください。

## 例 1

`input`:

```json
{
  "N": 3,
  "mountains": [
    { "S": "Everest", "T": 8849 },
    { "S": "K2", "T": 8611 },
    { "S": "Kangchenjunga", "T": 8586 }
  ]
}
```

期待される `output`:

```json
"K2"
```

世界で 2 番目に高い山は `K2` です。

## 例 2

`input`:

```json
{
  "N": 4,
  "mountains": [
    { "S": "Kita", "T": 3193 },
    { "S": "Aino", "T": 3189 },
    { "S": "Fuji", "T": 3776 },
    { "S": "Okuhotaka", "T": 3190 }
  ]
}
```

期待される `output`:

```json
"Kita"
```

日本で 2 番目に高い山は北岳です。

## 例 3

`input`:

```json
{
  "N": 4,
  "mountains": [
    { "S": "QCFium", "T": 2846 },
    { "S": "chokudai", "T": 2992 },
    { "S": "kyoprofriends", "T": 2432 },
    { "S": "penguinman", "T": 2390 }
  ]
}
```

期待される `output`:

```json
"QCFium"
```

## 出典

この問題は マイナビプログラミングコンテスト2021（AtCoder Beginner Contest 201）B「Do you know the second highest mountain?」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc201/tasks/abc201_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
