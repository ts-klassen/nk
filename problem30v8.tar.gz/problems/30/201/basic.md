# 3つの数を等差数列に並べ替える

## 問題

3 つの整数からなる配列 `A` が与えられます。

`A` の要素を好きな順番に並べ替えたとき、左から順に `x`, `y`, `z` として `z - y` と `y - x` が等しくなるようにできますか。

## 入力

`input` には、長さ 3 の整数の配列 `A` が入っています。

配列 `A` の各整数は 1 以上 100 以下です。

## 出力

`output` に、`A` を並べ替えて等差数列にできるなら `"Yes"`、できないなら `"No"` の文字列を代入してください。

## 例 1

`input`:

```json
[5, 1, 3]
```

期待される `output`:

```json
"Yes"
```

例えば `[1, 3, 5]` と並べ替えると、隣り合う差がどちらも 2 になります。

## 例 2

`input`:

```json
[1, 4, 3]
```

期待される `output`:

```json
"No"
```

どのように並べ替えても等差数列にはできません。

## 例 3

`input`:

```json
[5, 5, 5]
```

期待される `output`:

```json
"Yes"
```

すべての要素が等しい場合も等差数列です。

## 出典

この問題は マイナビプログラミングコンテスト2021（AtCoder Beginner Contest 201）A「Tiny Arithmetic Sequence」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc201/tasks/abc201_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
