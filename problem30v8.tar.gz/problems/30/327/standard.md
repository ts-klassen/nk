# A の A 乗

## 問題

正の整数 `A` について、`A` を `A` 乗した値を `A^A` と表します。

整数 `B` が与えられます。`A^A = B` であるような正の整数 `A` が存在するかを調べてください。

## 入力

`input` には整数 `B` が入っています。

制約:

- `1 <= B <= 10^18`
- `B` は整数

## 出力

`A^A = B` であるような正の整数 `A` が存在する場合は、その値を `output` に代入してください。

存在しない場合は、`-1` を `output` に代入してください。

## 例 1

`input`:

```json
27
```

期待される `output`:

```json
3
```

`3^3 = 27` です。

## 例 2

`input`:

```json
100
```

期待される `output`:

```json
-1
```

`A^A = 100` となる正の整数 `A` は存在しません。

## 例 3

`input`:

```json
10000000000
```

期待される `output`:

```json
10
```

`10^10 = 10000000000` です。

## 出典

この問題は HHKBプログラミングコンテスト2023(AtCoder Beginner Contest 327) B「A^A」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc327/tasks/abc327_b?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
