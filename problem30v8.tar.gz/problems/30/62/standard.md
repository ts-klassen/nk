# Picture Frame

## 問題

縦 `H` 行、横 `W` 列の画像があります。
各マスは英小文字 1 文字で表されています。

この画像の上下左右を、太さ 1 マスの `"#"` で囲んだ新しい画像を作ってください。

## 入力

`input` には、整数 `H`、整数 `W`、文字列配列 `A` を持つオブジェクトが入っています。

`A` は画像を上から順に表しており、長さは `H` です。
`A` の各文字列の長さは `W` で、各文字は英小文字です。

制約:

- `1 <= H, W <= 100`

## 出力

`output` に、画像の上下左右を `"#"` で囲んだ結果を、上から順に並べた文字列配列として代入してください。

## 例

`input`:

```json
{
  "H": 2,
  "W": 3,
  "A": ["abc", "arc"]
}
```

期待される `output`:

```json
["#####", "#abc#", "#arc#", "#####"]
```

## 出典

この問題は AtCoder Beginner Contest 062 B「Picture Frame」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc062/tasks/abc062_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
