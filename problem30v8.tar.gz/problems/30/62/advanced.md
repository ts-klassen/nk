# チョコレートバー

## 問題

縦 `H` ブロック、横 `W` ブロックの板チョコがあります。
この板チョコを、ブロックの境目に沿ってちょうど `3` つのピースに分けます。
それぞれのピースは長方形でなければなりません。

`3` つのピースの面積をできるだけ均等にしたいとします。
`3` つのピースの面積の最大値を `Smax`、最小値を `Smin` としたとき、`Smax - Smin` としてあり得る最小値を求めてください。

## 入力

`input` には、整数 `H` と `W` を持つオブジェクトが入っています。

```json
{
  "H": 3,
  "W": 5
}
```

`H` と `W` は次の条件を満たします。

- `2 <= H, W <= 100000`

## 出力

`output` に、`Smax - Smin` の最小値を数値で代入してください。

## 例

### 例 1

`input`:

```json
{
  "H": 3,
  "W": 5
}
```

期待される `output`:

```json
0
```

### 例 2

`input`:

```json
{
  "H": 4,
  "W": 5
}
```

期待される `output`:

```json
2
```

### 例 3

`input`:

```json
{
  "H": 5,
  "W": 5
}
```

期待される `output`:

```json
4
```

### 例 4

`input`:

```json
{
  "H": 100000,
  "W": 2
}
```

期待される `output`:

```json
1
```

### 例 5

`input`:

```json
{
  "H": 100000,
  "W": 100000
}
```

期待される `output`:

```json
50000
```

## 出典

この問題は AtCoder Beginner Contest 062 C「Chocolate Bar」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc062/tasks/arc074_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
