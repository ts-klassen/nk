# K 進数の桁数

## 問題

整数 `N` を `K` 進数で表したとき、何桁になるかを求めてください。

たとえば、`11` を `2` 進数で表すと `1011` なので、桁数は `4` です。

## 入力

`input` には、整数 `N` と `K` を持つオブジェクトが入っています。

- `1 <= N <= 10^9`
- `2 <= K <= 10`

## 出力

`output` に、整数 `N` を `K` 進数で表したときの桁数を表す整数を代入してください。

## 例

`input`:

```json
{ "N": 11, "K": 2 }
```

期待される `output`:

```json
4
```

`input`:

```json
{ "N": 1010101, "K": 10 }
```

期待される `output`:

```json
7
```

`input`:

```json
{ "N": 314159265, "K": 3 }
```

期待される `output`:

```json
18
```

## 出典

この問題は AtCoder Beginner Contest 156 B「Digits」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc156/tasks/abc156_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
