# TLD

## 問題

英小文字と `.` だけからなる文字列 `S` が与えられます。

`S` を `.` で区切ったとき、一番最後に現れる文字列を求めてください。これは、`.` を含まない `S` の接尾辞のうち最長のものです。

## 入力

`input` には、次の条件を満たす文字列 `S` が入っています。

- `S` は英小文字と `.` だけからなる、長さ `2` 以上 `100` 以下の文字列です。
- `S` には `.` が `1` つ以上含まれます。
- `S` の末尾は `.` ではありません。

## 出力

`output` に、`S` を `.` で区切ったときの最後の文字列を代入してください。

## 例

`input`:

```json
"atcoder.jp"
```

期待される `output`:

```json
"jp"
```

`input`:

```json
"translate.google.com"
```

期待される `output`:

```json
"com"
```

`input`:

```json
".z"
```

期待される `output`:

```json
"z"
```

`input`:

```json
"..........txt"
```

期待される `output`:

```json
"txt"
```

## 出典

この問題は 日本レジストリサービス（JPRS）プログラミングコンテスト2024（AtCoder Beginner Contest 339） A「TLD」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc339/tasks/abc339_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
