# パスカルの三角形を作る

## 問題

整数 `N` が与えられます。

次のように定められる `N` 個の整数列 `A_0, A_1, ..., A_{N-1}` を作ってください。

- 各 `i` について、`A_i` の長さは `i + 1` です。
- `A_i` の `j + 1` 番目の値を `a_{i,j}` とします。
- `j = 0` または `j = i` のとき、`a_{i,j} = 1` です。
- それ以外のとき、`a_{i,j} = a_{i-1,j-1} + a_{i-1,j}` です。

制約:

- `1 <= N <= 30`
- `N` は整数

## 入力

`input` には整数 `N` が入っています。

## 出力

`output` に、`A_0` から `A_{N-1}` までを順に並べた二次元配列を代入してください。

各 `A_i` は、長さ `i + 1` の整数配列です。

## 例

`input`:

```json
3
```

期待される `output`:

```json
[
  [1],
  [1, 1],
  [1, 2, 1]
]
```

## 出典

この問題は AtCoder Beginner Contest 254 B「Practical Computing」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc254/tasks/abc254_b?lang=ja
- 権利表記: Copyright Since 2012 (c) AtCoder Inc. All rights reserved.
