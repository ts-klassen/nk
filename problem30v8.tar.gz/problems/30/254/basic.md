# 下 2 桁

## 問題

整数 `N` が与えられます。

`N` の下 2 桁を求めてください。ここで下 2 桁とは、十の位と一の位をこの順に並べた 2 文字の文字列のことです。

## 入力

`input` には、100 以上 999 以下の整数 `N` が入っています。

## 出力

`output` に、`N` の下 2 桁を表す 2 文字の文字列を代入してください。

## 例 1

`input`:

```json
254
```

期待される `output`:

```json
"54"
```

`254` の下 2 桁は `54` です。

## 例 2

`input`:

```json
101
```

期待される `output`:

```json
"01"
```

`101` の下 2 桁は `01` です。

## 出典

この問題は AtCoder Beginner Contest 254 A「Last Two Digits」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc254/tasks/abc254_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
