# 素晴らしい文字列

## 問題

英大文字と英小文字だけからなる文字列について、次の 3 つをすべて満たすとき、その文字列を「素晴らしい文字列」と呼びます。

- 英大文字が 1 文字以上含まれている。
- 英小文字が 1 文字以上含まれている。
- すべての文字が互いに異なる。

例えば、`AtCoder` や `Aa` は素晴らしい文字列です。一方、`atcoder` は英大文字を含まず、`Perfect` は同じ文字を複数含むため、素晴らしい文字列ではありません。

文字列 `S` が与えられます。`S` が素晴らしい文字列か判定してください。

## 入力

`input` には、英大文字と英小文字だけからなる文字列 `S` が入っています。

`S` の長さは 1 文字以上 100 文字以下です。

## 出力

`S` が素晴らしい文字列なら `output` に `"Yes"` を代入してください。

そうでなければ `output` に `"No"` を代入してください。

## 例 1

`input`:

```json
"AtCoder"
```

期待される `output`:

```json
"Yes"
```

`AtCoder` は、英大文字と英小文字をどちらも含み、すべての文字が互いに異なります。

## 例 2

`input`:

```json
"Aa"
```

期待される `output`:

```json
"Yes"
```

`A` と `a` は別の文字として扱います。

## 例 3

`input`:

```json
"atcoder"
```

期待される `output`:

```json
"No"
```

英大文字が含まれていません。

## 例 4

`input`:

```json
"Perfect"
```

期待される `output`:

```json
"No"
```

同じ文字 `e` が複数含まれています。

## 出典

この問題は モノグサプログラミングコンテスト2022（AtCoder Beginner Contest 249） B「Perfect String」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc249/tasks/abc249_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
