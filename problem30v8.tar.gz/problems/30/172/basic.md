# 三乗までの和

## 問題

整数 `a` について、`a + a^2 + a^3` の値を求めます。

## 入力

`input` には整数 `a` が入っています。

制約:

- `1 <= a <= 10`
- `a` は整数

## 出力

`output` に、`a + a^2 + a^3` の値を整数として代入してください。

## 例

`input`:

```json
2
```

期待される `output`:

```json
14
```

`a = 2` のとき、`2 + 2^2 + 2^3 = 2 + 4 + 8 = 14` です。

## 出典

この問題は AtCoder Beginner Contest 172 A「Calc」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc172/tasks/abc172_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
