# 文字列の違いを数える

## 問題

同じ長さの英小文字の文字列 `S` と `T` が与えられます。

`S` の 1 文字を選んで別の文字に書き換える操作を繰り返して、`S` を `T` と同じ文字列にします。

このとき、必要な操作回数の最小値を求めてください。

## 入力

`input` には、文字列 `S` と `T` を持つオブジェクトが入っています。

```json
{
  "S": "cupofcoffee",
  "T": "cupofhottea"
}
```

`S` と `T` は次の条件を満たします。

- `S` と `T` の長さは 1 以上 200000 以下です。
- `S` と `T` は英小文字だけからなります。
- `S` と `T` の長さは等しいです。

## 出力

`output` に、`S` を `T` にするために必要な操作回数の最小値を表す整数を代入してください。

## 例

`input`:

```json
{
  "S": "cupofcoffee",
  "T": "cupofhottea"
}
```

期待される `output`:

```json
4
```

6 文字目、8 文字目、9 文字目、11 文字目を書き換えると、4 回の操作で `T` と同じ文字列にできます。

## 出典

この問題は AtCoder Beginner Contest 172 B「Minor Change」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc172/tasks/abc172_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
