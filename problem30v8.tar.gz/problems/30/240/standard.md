# 異なる整数の個数

## 問題

長さ `N` の正整数列 `A = [A_1, A_2, ..., A_N]` が与えられます。

`A` に現れる整数は何種類あるか求めてください。

## 入力

`input` には、整数 `N` と配列 `A` を持つオブジェクトが入っています。

`A` の長さは `N` です。

- `1 <= N <= 1000`
- `1 <= A_i <= 1000000000`

## 出力

`output` に、`A` に現れる異なる整数の個数を表す整数を代入してください。

## 例

### 例 1

`input`:

```json
{
  "N": 6,
  "A": [1, 4, 1, 2, 2, 1]
}
```

期待される `output`:

```json
3
```

`A` には `1`, `2`, `4` の 3 種類の整数が現れます。

### 例 2

`input`:

```json
{
  "N": 1,
  "A": [1]
}
```

期待される `output`:

```json
1
```

### 例 3

`input`:

```json
{
  "N": 11,
  "A": [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
}
```

期待される `output`:

```json
7
```

## 出典

この問題は AtCoder Beginner Contest 240 B「Count Distinct Integers」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc240/tasks/abc240_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
