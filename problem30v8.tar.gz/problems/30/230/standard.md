# Triple Metre

## 問題

文字列 `T` を、`oxx` を 100000 個つなげた文字列として考えます。

`input` として文字列 `S` が与えられます。`S` が `T` の連続する一部分として現れるなら、`output` に `"Yes"` を代入してください。そうでないなら、`output` に `"No"` を代入してください。

## 入力

`input` には、`o` と `x` のみからなる文字列 `S` が入っています。

`S` の長さは 1 以上 10 以下です。

## 出力

`output` に `"Yes"` または `"No"` の文字列を代入してください。

## 例

`input`:

```json
"xoxxoxxo"
```

期待される `output`:

```json
"Yes"
```

`input`:

```json
"xxoxxoxo"
```

期待される `output`:

```json
"No"
```

`input`:

```json
"ox"
```

期待される `output`:

```json
"Yes"
```

## 出典

この問題は AtCoder Beginner Contest 230 B「Triple Metre」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc230/tasks/abc230_b?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
