# AGC のコンテスト名

## 問題

AtCoder Grand Contest、略して AGC は 54 回開催されています。

もともと、`N` 回目の AGC のコンテスト名は、`N` を 3 桁になるようにゼロ埋めした `AGCXXX` という形式でした。たとえば、1 回目は `AGC001`、2 回目は `AGC002` です。

ただし、`AGC042` は欠番です。そのため、42 回目以降に開催された AGC では、開催回数より 1 大きい番号が使われています。たとえば、42 回目の AGC は `AGC043` です。

整数 `N` が与えられるので、`N` 回目に開催された AGC のコンテスト名を求めてください。

## 入力

`input` には整数 `N` が入っています。

- `1 <= N <= 54`

## 出力

`output` に、`N` 回目に開催された AGC のコンテスト名を `AGCXXX` の形式の文字列で代入してください。

`XXX` は、3 桁になるようにゼロ埋めされた番号です。

## 例 1

`input`:

```json
42
```

期待される `output`:

```json
"AGC043"
```

## 例 2

`input`:

```json
19
```

期待される `output`:

```json
"AGC019"
```

## 例 3

`input`:

```json
1
```

期待される `output`:

```json
"AGC001"
```

## 例 4

`input`:

```json
50
```

期待される `output`:

```json
"AGC051"
```

## 出典

この問題は AtCoder Beginner Contest 230 A「AtCoder Quiz 3」をもとに、この教材の実行形式に合わせて改変しています。

- 元問題: https://atcoder.jp/contests/abc230/tasks/abc230_a?lang=ja
- 権利表記: Copyright (c) AtCoder Inc. All rights reserved.
